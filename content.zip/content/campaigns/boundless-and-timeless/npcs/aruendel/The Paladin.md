---
title: "## Profile"
gender: Male
race: Human
age: Adult
class: Paladin
alignment: Lawful Good
location: Aruendel
---

# 
## Profile

<% tp.file.cursor() %>
**<Add description here, extend it with AI Text Generator using Ctrl J>**

> [!info] statblock
>

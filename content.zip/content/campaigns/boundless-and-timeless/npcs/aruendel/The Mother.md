---
title: "## Profile"
gender: Female
race: Half-Elf
age: Adult
class: Sorcerer / Warlock
alignment: True Neutral
location: Aruendel
---

# 
## Profile

<% tp.file.cursor() %>
**<Add description here, extend it with AI Text Generator using Ctrl J>**

> [!info] Statblock
>

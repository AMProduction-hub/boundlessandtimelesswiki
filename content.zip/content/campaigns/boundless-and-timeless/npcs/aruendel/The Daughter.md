---
title: "## Profile"
gender: Female
race: Human
age: Adult
class: Sorcerer
alignment: Chaotic Good
location: Aruendel
---

# 
## Profile

<% tp.file.cursor() %>
**<Add description here, extend it with AI Text Generator using Ctrl J>**

> [!info] Statblock
>

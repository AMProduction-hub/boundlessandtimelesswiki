---
title: "## Profile"
gender: Male
race: Human
age: Adult
class: Fighter
alignment: Lawful Good
location: Aruendel
---

# 
## Profile

Elian or Ser Elian is a noble son who inspired to become a knight of a tales.
### Personality 
#### **Ser Elian's Half-Remembered Heroic Quotes (d12)**
1. **"Steel may bend... but, uh, courage is harder!"**
2. **"The stars keep an eye on dreamers, or something like that!"**
3. **"A sword swung for justice doesn't need... a fancy cover!"**
4. **"One little candle can fight off a whole army of darkness!"**
5. **"Oaths are like wings! They, uh, help you... fly above fear!"**
6. **"The road to glory's just a lot of stubborn walking, really."**
7. **"Better to trip with honor than crawl like a coward!"**
8. **"A good heart makes the best kind of shield!"**
9. **"Valor’s like... a forge? No! A fire! A fire in your soul!"**
10. **"By wind, by stone, by... well, whatever's around — I’ll stand!"**
11. **"In the quiet between heartbeats... that's when real courage shouts!"**
12. **"No one sings about the folks who ran away, you know!"**

> [!info] Statblock
>

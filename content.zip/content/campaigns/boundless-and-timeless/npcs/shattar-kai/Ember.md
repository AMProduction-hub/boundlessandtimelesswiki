---
title: "Ember"
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
tags:
  - Category/General-Characters-Article
parent:
  - General Characters Article
up:
  - General Characters Article
prev:
  - Template - Class
next:
  - Template - Race
RWtopicId: Topic_50
gender: Female
race: Human
age: Adult
class: Rogue
alignment: Chaotic Neutral
location: Shattar Kai
---
# Ember
## Overview
Ember is the leader of Thieves Guild in Stalwart. Her interest is always to make her rich rather than saving lives.

## Plot Web

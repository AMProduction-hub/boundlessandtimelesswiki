---
title: "Father Malen"
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
tags:
  - Category/General-Characters-Article
parent:
  - General Characters Article
up:
  - General Characters Article
prev:
  - Template - Class
next:
  - Template - Race
RWtopicId: Topic_50
gender: Male
race: Tiefling
age: Old
class: Cleric (Kelemvor)
alignment: Chaotic Good
location: Shattar-Kai
---

# Father Malen
## Overview
Father Malen is the current head of House of Silence in Shattar-Kai a temple dedicated to [The Lord of the Dead - Kelemvor]({{< relref "faerunian-kelemvor-scag" >}}). Before he became head of House of Silence Father Malen once was a famous tailor in this lands and had [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) as his apprentice. His view of the world quite idealistic he want every people to have peace and be together. Now his works is overflow by sending men and women to their grave caused the wars that happen caused of [Fremen]({{< relref "fremen" >}}) & [Stalwart]({{< relref "stalwart" >}}).

## Plot Web 

- The Current Head of House of Silence.
	- Dedicating his life to Kelemvor teaching.
	- Overwhelm of works by burying dead and sending dead.
- Was a famous tailor before dedicating his life to House of Silence
	- [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) is one of his famous Apprentice.
- Personal Traits.
	- Tired of sending and burying people caused by the war.
	- Want people to live in peace.
	- Known the secret of Artifact that Bureau searching.

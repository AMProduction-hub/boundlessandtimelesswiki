---
title: "General Valtan"
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
tags:
  - Category/General-Characters-Article
parent:
  - General Characters Article
up:
  - General Characters Article
prev:
  - Template - Class
next:
  - Template - Race
RWtopicId: Topic_50
gender: Male
race: Human
age: Adult
class: Fighter (Cavalier)
alignment: Lawful Neutral
location: Shattar-Kai
---
# General Valtan
## Overview
Eric Valtan is the son of [General Valtan]({{< relref "general-valtan" >}}), he currently with his uncle (Envoy Valtan) to learn about the politics.

## Plot Web
- Ward to His Uncle (Envoy Valtan)
	- Tried to learn more about politics before stepping into real politics.
- Learn much from his father [General Valtan]({{< relref "general-valtan" >}})
	- Mastery at prolong warfare.
	- Logistic
	- Military Campaign Planning

---
title: "Sofia Fyrwurd"
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
tags:
  - Category/General-Characters-Article
parent:
  - General Characters Article
up:
  - General Characters Article
prev:
  - Template - Class
next:
  - Template - Race
RWtopicId: Topic_50
gender: Female
race: Half-Elf
age: Adult
class: Cleric
alignment: Chaotic Good
location: Shattar Kai
---
# Sofia Fyrwurd
## Overview
Sofia Fyrwurd is [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}})'s sister. She follows where Nikael goes even though most of the time question his leads. She often helps around the camps like cooking foods, managing rations, and heals the wounded.

## Plot Web

---
title: "General Valtan"
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
tags:
  - Category/General-Characters-Article
parent:
  - General Characters Article
up:
  - General Characters Article
prev:
  - Template - Class
next:
  - Template - Race
RWtopicId: Topic_50
gender: Male
race: Human
age: Old
class: Fighter (Cavalier)
alignment: Lawful Neutral
location: Shattar-Kai
---
# General Valtan
## Overview
General Valtan was the current Military leader of Stalwart. His main job is to protect Stalwart and push Fremen attack

## Plot Web
- Military Leader of Stalwart
	- Also controlling Tunnel of Grim.
	- Master in prolong warfare.
- Personal Traits
	- Was the first customer [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) when he opens his tailor shop in Stalwart.
	- Known that in the long run Stalwart will stands but with the cost of no Forest Resources.

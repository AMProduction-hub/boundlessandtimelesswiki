---
title: "Nikael of Fire Banner"
ImportedOn: Saturday, 18 December 2021 8:41:47 PM
tags:
  - Category/General-Characters-Article
parent:
  - General Characters Article
up:
  - General Characters Article
prev:
  - Template - Class
next:
  - Template - Race
RWtopicId: Topic_50
gender: Male
race: Half-Elf
age: Adult
class: Rogue (Mastermind)
alignment: Chaotic Neutral
location: Shattar Kai
---
# Nikael of Fire Banner
## Overview
Born as Nikael Fyrwurd he reborn as Nikael of Fire Banner the leader of opposite group of Stalwart called Fremen. Nikael start the Fremen groups after hearing the High Council of Stalwart want to expand and use many of the lands resources especially forest resources, this makes Nikael want to oppose this and use whatever skills he had while he still a Stalwart citizen to make this not happens. Until at some point the Council exiled Nikael and people who follows from Stalwart in there Nikael make a promises to the Council, that he will defeat Stalwart. There he created a group called "Fremen" a freedom-fighter that wants to maintain all the resources.

## Plot Web
- Nikael was a Famous Tailor before creating Fremen.
	- [Father Malen]({{< relref "father-malen" >}}) is his mentor in tailorship.
	- His works stills around and some important people in Stalwart stills wears them.
- Leader of "Fremen"
	- Wants to protect the lands from exploitation by any means necessary.
	- Competent in Guerilla Warfare.
- Was Citizen of Stalwart until exiled by the Council of Stalwart
	- Promised to the Council that he will defeat Stalwart.
	- Many citizen of Stalwart become sympathisant to Nikael Fyrwurd's ideals also got exiled.
- [Father Malen]({{< relref "father-malen" >}})
	- Was Nikael's mentor.
	- Some people thinks that Nikael had his ideals becaused of [Father Malen]({{< relref "father-malen" >}}) teachings.
- Personal Traits
	- Wants to protect the land by any means necessary, most often ends in violence.
	- Had ability to guilt trip people to support his values and ideals.

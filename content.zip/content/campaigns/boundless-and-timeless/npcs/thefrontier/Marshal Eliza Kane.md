---
title: "## Profile"
gender: Female
race: Human
age: Adult (30's)
class: Fighter (Gunslinger)
alignment: Lawful
location: The Frontier, Ye Olde Town
---

# 
## Profile

## Statblock

---
title: "## Profile"
gender: Male
race: Human
age: Adult
class: Rogue (Mastermind)
alignment: Chaotic Neutral
location: The Frontier, Dustbowl
---

# 
## Profile
> [!info] Statblock
>

---
title: "## Profile"
gender: Male
race: Gnome
age: Adult
class: Artificier
alignment: Chaotic Good
location: The Frontier, Thinkwistle's Lab
---

# 
## Profile

---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
- [Jeno]({{< relref "jeno" >}}). The Wizard
- [Klir]({{< relref "klir" >}}). The Rogue.
 
## Session Overview 
 
Party mendapatkan tugas dari [Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}}) untuk menuju Shattar-Kai mencari Artifact bersama [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) yang memiliki tugas lain dari Bureau sebagai diplomat untuk para kubu di Shattar-Kai.

## Key Learnings

- Party diminta mencari tahu lokasi Artifact dengan menanyakannya kepada orang yang kira-kira terlihat penting.
- Sedang terjadi perang antar kubu Stalwart dan Fremen yang terjadi di Shattar-Kai dimulai 5 tahun yang lalu ketika Nikael (pemimpin Fremen) melawan kebijakan yang kubu Stalwart.
- Nikael sebelum menjadi pemimpin Fremen dikenal sebagai penjahit yang terkenal, dia didik oleh Father Malen yang sekarang menjaga House of Silence.
- Tunnel of Grim dijaga ketat oleh pasukan Stalwart karena merupakan sumber mineral dan emas yang dimana yang menggali adalah tawanan Stalwart.
- Stalwart di Shattar-Kai menguasai; 1. Pelabuhan, 2. Tambang, 3. Jalan.  *Ideals Stalwart*; **Progress**.
- Fremen di Shattar-Kai menguasai; 1. Perikanan, 2. Perhutanan, 3. Hewan-hewan di hutan. *Ideals Fremen; **Maintain at all cost**. 
 
## Who Did They Meet?
 
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).
- Port of Stalwart's Innkeeper.
- Pemilik rumah yang terdapat notice board nya.
 
## Items Of Importance
 
- Pacul Leluhur (1d4) dengan property +Haste ketika menggali tanah.
- Cincin dengan ruby biru muda. Property; +1 Strength Ability, -1 all Saves Throws.

## What Worked 
 
- Menjual teman lagi ?

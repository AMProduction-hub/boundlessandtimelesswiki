---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock. 
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
- [Jeno]({{< relref "jeno" >}}). The Wizard
- [Klir]({{< relref "klir" >}}). The Rogue.
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin.

Away:
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter.
 
## Session Overview 
 
Party memulai petualangan di Fremen Camp. Party bertemu dengan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dan mencoba membahas bagaimana mencoba mendamaikan [Fremen]({{< relref "fremen" >}}) & [Stalwart]({{< relref "stalwart" >}}) sebelum bertemu dengan [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}). Party bertemu dengan [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) yang memberikan proposal perdamaian kepada [Stalwart]({{< relref "stalwart" >}}) dengan harapan bisa disampaikan kepada Stalwart. Party kemudian ditugaskan untuk mengirimkan surat kepada Eric, Thieves Guild di Stalwart. Party mencari tahu Eric yang kemudian mereka mengetahui bahwa Eric adalah putra dari [General Valtan]({{< relref "general-valtan" >}}). Kemudian party mendapatkan informasi kalau [Eric Valtan]({{< relref "eric-valtan" >}}) ada di gedung administrasi [Stalwart]({{< relref "stalwart" >}}) kemudian party mendatangi gedung itu dan menemui [Eric Valtan]({{< relref "eric-valtan" >}}) untuk diberikan surat dari [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}). [Eric Valtan]({{< relref "eric-valtan" >}}) juga menginformasikan kepada party bahwa akan adanya pesta di [Stalwart]({{< relref "stalwart" >}}) yang akan didatangi oleh petinggi-petinggi [Stalwart]({{< relref "stalwart" >}}).

## Key Learnings

- Gencatan Senjata tersisa: 2 Day 1 Malam.
- Proposal [Fremen]({{< relref "fremen" >}}); Berhentinya eksploitasi hutan berlebihan, membuat Tunnel of Grim menjadi milik netral, dan Bastion Of [Stalwart]({{< relref "stalwart" >}}) menjadi pusat kepemerintahan [Fremen]({{< relref "fremen" >}}).
- [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) memberikan tugas untuk memberikan surat kepada [Eric Valtan]({{< relref "eric-valtan" >}}), Thieves Guild Stalwart.
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dijodohkan dengan [Eric Valtan]({{< relref "eric-valtan" >}}) supaya ada tahap perdamaian.
- [Eric Valtan]({{< relref "eric-valtan" >}}) memberi tahu akan adanya pesta di malam ini.
 
## Who Did They Meet?
 
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}})
- [Eric Valtan]({{< relref "eric-valtan" >}})
- [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}})
- Orang dari Thieves Guild yang [Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}) suruh lari.
 
## Items Of Importance
 
- 

## What Worked 
- Charm Person kepada seseorang untuk meminta bekerja sama dengan Party.

---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
- [Jeno]({{< relref "jeno" >}}). The Wizard
- [Klir]({{< relref "klir" >}}). The Rogue.

Away:
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin.
 
## Session Overview 
 
Party memulai hari di kapal Pequod kemudian membuat pentas di kota Port of Stalwart untuk menyebarkan kabar diadakannya Gencatan Senjata yang sudah di tanda tangani oleh [Fremen]({{< relref "fremen" >}}) dan [Stalwart]({{< relref "stalwart" >}}). Party kemudian mencoba mencari orang yang rumahnya ada notice boardnya, dia meminta kepada player untuk coba menyelidiki sumber kebakaran yang ada di Port of Stalwart, tetapi party mengatakan mereka akan memberitahu pihak Stalwart, kemudian melanjutkan perjalanan ke House of Fisher. di House of Fisher, party menemui 

## Key Learnings

- Steve adalah anak dari korban kebakaran di Port of Stalwart yaitu Aline & Cedric. Menurut informasi yang player terima mereka biasa berkomunikasi dengan warga yang tinggal di House of Fisher.
- House of Fisher ditempati oleh [Half-Orc]({{< relref "half-orc" >}}). Mereka di "paksa" me-supply hasil laut kepada [Fremen]({{< relref "fremen" >}}) & [Stalwart]({{< relref "stalwart" >}}) dengan janji mereka akan di naturalisasi jadi bagian mereka. Maka dari itu para penduduk di House of Fisher menjarah kapal-kapal kemudian menjual barang yang terlihat berharga.
- [Sofia]({{< relref "sofia-fyrwurd" >}}) di Freemen Camp mengaku sebagai adik dari [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}).
- Gencatan Senjata memasuki: 2 hari, 2 malam saat sesi ini.
 
## Who Did They Meet?
 
- Seseorang di Port of Stalwart yang rumahnya memiliki notice board.
- Pemimpin [Half-Orc]({{< relref "half-orc" >}}) di House of Fisher
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}})
 
## Items Of Importance
 
- 

## What Worked 
 - Menyanyikan lagu perdamaian untuk membuat orang-orang minat untuk berdamai ?

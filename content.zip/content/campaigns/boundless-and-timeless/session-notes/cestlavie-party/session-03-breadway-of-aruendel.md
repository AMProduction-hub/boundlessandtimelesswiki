---
title: "**DM Notes to Player:**"
tags: [timeline, SessionJournals]
---

## Characters 
 
**[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
 
**[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk. 
 
**[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 

**[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
 
## Session Overview 
 
Party menuju Plane Aruendel yang jauh di Far Realm untuk mencari Sir Aldric yang merupakan mantan agent Bureau yang sedang melindungi artifak yang dicari oleh Bureau.

## Key Learnings

- [Shaperite]({{< relref "shaperite-the-agent" >}}) mengatakan harus berhati-hati jika bertemu dengan [Damian]({{< relref "damian-the-squeeky-devils" >}}), dengan peringatan _apapun yang dia bicarakan bisa saja memecah party_.
- Bertemu dengan pekerja kontrak #666 atau [Damian]({{< relref "damian-the-squeeky-devils" >}}) di desa Brindlewatch yang bekerja sebagai _Royal Messenger_ kerajaan Aruendel yang diduduki oleh keluarga _Mauclair_. [Damian]({{< relref "damian-the-squeeky-devils" >}}) yang menjelma sebagai Human form nya dia mengatakan bahwa para _Royal Wizard_ mengatakan ada suatu anomali di daerah sekitar sejarah Aruendel dan [Damian]({{< relref "damian-the-squeeky-devils" >}}) mengatakan party adalah _catalyst_ dari anomali itu.
- 33 tahun yang lalu, kumpulan bangsawan di Aruendel berusaha untuk menguasai kerajaan menggunakan sihir dan keluarga _Mauclair_ adalah salah satu keluarga yang hampir di bumi hanguskan oleh kumpulan bangsawan yang ingin menguasai sampai kumpulan petualang yang dipimpin oleh [Aldric]({{< relref "the-paladin" >}}) bersama kawan-kawannya berhasil menghentikan kekuatan sihir yang digunakan oleh para bangsawan dan menyelamatkan para keluarga _Mauclair_ yang tersisah.
- Saat di dalam mimpi para party didatangi oleh _Shadowy Figure_ dan mendapat Ultimatum untuk memberikan cincin ruby yang mereka temukan di _Mondell Valley_ kepada seorang yang memiliki rambut setengah coklat dan setengah berwarna terang. Jika mereka tidak memberikannya pada waktu _**1 Hari**_ maka pasukan si _Shadowy Figure_ akan menyerang mereka.
- Party berhasil menemui [Aldric]({{< relref "the-paladin" >}}) dan putri nya di Benteng Caerthwyn di kereta dagang roti mereka.
 
## Who Did They Meet?
 
**[Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).** Bertemu di desa Brindlewatch. Ditemui oleh [Alizar Valts]({{< relref "alizar-valts" >}}) & [Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}) 
 
**Seorang Pria Tua di Inn Brindlewatch**. Dia menyeritakan kejadian yang terjadi 30 tahun yang lalu dan mengenali siapa yang mengutus party. Dia juga menjelaskan 
 
**[Aldric]({{< relref "the-paladin" >}}) & [Putri-nya]({{< relref "the-daughter" >}}).** Yang sedang berada di kereta dagang mereka di Benteng Caerthwyn. Ditemui awal oleh [Gwyn]({{< relref "gwyn" >}}) & [Ashenka Roïs]({{< relref "ashenka-roïs" >}})

**Kepala Desa Brindlewatch**. 

**Shadowy Figure**. Party temui di dalam mimpi dan diberi Ultimatum untuk memberikan Cincin Ruby kepada orang yang berhak memilikinya.
 
## Items Of Importance
 
- [Gwyn]({{< relref "gwyn" >}}) mendapatkan lantern dari Bureau
- Cincin Ruby dan catatan _"Aku selalu bersamamu dari jauh, buah hatiku ~Sang Ibu"_
- Cincin dengan batu berwarna hijau.
- Amulet dengan emblem keluarga _Mauclair_.

## What Worked 
 
- Menjual teman sebagai _jasa_ kepada NPC bisa menghadiahkan uang untuk party. Terutama kepada NPC yang terlihat sendirian dan terlihat kaya.

# **DM Notes to Player:**
- Ketika didalam roleplay atau ketika di meja dan pemain merasa tidak nyaman untuk melakukan atau roleplay atau "act" sebagai karakter. Player bisa segera bilang ke DM atau bilang _safeword_ yaitu nama party. Ty ^_^

---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 

Away:
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
 
## Session Overview 
 
Party mencoba menemui cleric yang bertempatkan di Tebing Merak dan meminta tolong untuk mengirimkan pesan kepada [Aldric]({{< relref "the-paladin" >}}) untuk mengetahui kapan [Aldric]({{< relref "the-paladin" >}}) akan datang dan siapakah [Elian]({{< relref "the-don-quixote" >}}), dan dibalas kalau [Elian]({{< relref "the-don-quixote" >}}) adalah utusannya dan dia akan datang dalam waktu 12 jam. Kemudian party berkeliling untuk memakan waktu hingga datangnya Aldric mereka pun akhirnya mencoba menuju reruntuhan Benteng Caerthwyn yang dimana ada kolam ikan yang bercahaya jika didatangi oleh [Elira]({{< relref "the-daughter" >}}). Ketika Party, [Elira]({{< relref "the-daughter" >}}), dan [Elian]({{< relref "the-don-quixote" >}}) tiba di kolam yang ada di reruntuhan Benteng Caerthwyn dan Party meminta [Elira]({{< relref "the-daughter" >}}) untuk coba mendatangi kolam ikan itu, ketika [Elira]({{< relref "the-daughter" >}}) mendatangi kolam tersebut tiba-tiba dia tertarik kedalam kolam meninggalkan amulet yang dia pakai, ketika [Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}) mencoba memahami apa yang terjadi di kolam itu ternyata ada yang menggunakan Spell [Gate]({{< relref "gate" >}}), kemudian Party di hampiri oleh [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) yang memberi informasi kalau [Elira]({{< relref "the-daughter" >}}) sedang menjadi tawanan di Nyx's Ring oleh para Praktisi Sihir, Party pun berusaha untuk menyelamatkan [Elira]({{< relref "the-daughter" >}}) dari Nyx's Ring dan berencana membawanya ke Danau Estara dimana Party awal mendarat. Party berhasil menyelamatkan [Elira]({{< relref "the-daughter" >}}) dari Nyx's Ring dan mulai melakukan perjalanan menuju Danau Estara, setiap mereka menuju perjalanan ke Danau Estara mereka di hadangi oleh pasukan yang mengatakan kalau mereka adalah pasukan [Aldric]({{< relref "the-paladin" >}}) yang sedang mencari penyihir untuk dihabisi.

## Key Learnings

- Praktisi Sihir sudah mulai berkumpul di Nyx's Ring.
- Pasukan [Aldric]({{< relref "the-paladin" >}}) sudah berada di bagian Aruendel dimana Party berada untuk melakukan penyerangan ke para praktisi Sihir.
- Party sudah mendapatkan amulet yang [Selaveth]({{< relref "the-mother" >}}) katakan tempat penyimpanan Artifact yang Bureau cari.
- [Elira]({{< relref "the-daughter" >}}) dan [Elian]({{< relref "the-don-quixote" >}}) masih mengikuti Party menuju Danau Estara.
 
## Who Did They Meet?
 
- Beberapa praktisi sihir di Nyx's Ring
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
- [Elira]({{< relref "the-daughter" >}})
- [Elian]({{< relref "the-don-quixote" >}})
 
## Items Of Importance
 
- Amulet milik [Elira]({{< relref "the-daughter" >}}) yang menunjukkan logo Bureau.

## What Worked 
 
- Mencoba mengendap-endap memasuki camp musuh sepertinya cara yang bijak.

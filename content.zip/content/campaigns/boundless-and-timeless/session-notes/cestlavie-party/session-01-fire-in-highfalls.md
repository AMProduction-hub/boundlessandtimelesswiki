---
tags: [timeline, SessionJournals]
---

## Characters 
 
**[Alizar Valts]({{< relref "player-characters/alizar-valts" >}}).** Description. 
 
**[Ashenka Roïs]({{< relref "player-characters/ashenka-roïs" >}}).** Description. 
 
**[Gwyn]({{< relref "player-characters/gwyn" >}}).** Description. 
 
**[Meows Whiskerpop (Whisky)]({{< relref "player-character/whisky" >}}).** Description. 
 
## Session Overview 
 
Para party mendapatkan surat yang menjanjikan "*Petualangan Luar Biasa, Harta Fantastis. Temukan Aku di Lonesome Tavern*" Surat itu memberikan instruksi yang amat sangat kurang jelas akhirnya para party mencoba mencari arah di desa Highfalls yang dekat dengan sumber air Saratoga. Ketika sedang mencari informasi ternyata Highfalls tiba-tiba diserang oleh pasukan Zariel yang dipimpin oleh Komandan dengan cara membakar habis Highfalls dan menyurutkan sungai yang melewati Highfalls. Party pun membantu penduduk desa dan mengembalikan air yang tengah dibendung oleh para pasukan Komandan yang diutus oleh Zariel. 

## Key Learnings

- Pasukan Zariel berusaha untuk mengambil alih Highfalls dengan membumi hanguskan rumah-rumah penduduk.
- Party berhasil mengalahkan pasukan Zariel dan mengetahui jalan tercepat menuju Lonesome Tavern.
- Party berhasil datang ke Highfalls
 
## Who Did They Meet?
 
- **Kepala Desa Highfalls.** Seorang Cleric dewa Tyr yang juga menjadi Kepala Desa di Highfalls.
 
- **Komandan.** Keturunan Barbed Devil yang diutus oleh Zarieluntuk mengambil alih Highfalls.
 
- **[Shaperite - The Agent]({{< relref "npcs/bureauoftimeandplane/shaperite-the-agent" >}}).** Seorang pria yang menyambut para party di Lonesome Tavern.

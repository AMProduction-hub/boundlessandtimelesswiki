---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
 
## Session Overview 

Party sudah mendapatkan Artifact yang dicari oleh Bureau dan melanjutkan perjalanan menuju Danau Estara tempat dimana kapal Pequod berada bersama [Elira]({{< relref "the-daughter" >}}) & [Elian]({{< relref "the-don-quixote" >}}) dan meninggalkan Aruendel yang mulai hancur karena sisa-sisa sihir yang meluap. Akhirnya party meninggalkan Aruendel dan ketika mereka pergi melihat plane Aruendel yang awalnya penuh dengan warna sekarang gelap gulita dan hanya ada cahaya-cahaya aneh yang menyelimuti plane Aruendel.

## Key Learnings

- Kiamat di Aruendel telah terjadi ?!?
 
## Who Did They Meet?
 
- [Elira]({{< relref "the-daughter" >}})
- [Elian]({{< relref "the-don-quixote" >}})
 
## Items Of Importance
 
- Artifact Bureau

## What Worked 
 
-

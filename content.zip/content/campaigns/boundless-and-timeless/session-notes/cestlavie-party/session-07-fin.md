---
tags: [timeline, SessionJournals]
---

![](z_Assets/Misc/Fin.webp)

## Characters 
 
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
- [Jeno]({{< relref "jeno" >}}). The Wizard
- [Klir]({{< relref "klir" >}}). The Rogue.
 
## Session Overview 
 
Party sepakat untuk tidur di Inn yang ada di Port Of Stalwart. Sebangunnya (Hari masih Malam) mereka mendengar ada rombongan kuda dan tiba-tiba ada teriakan seseorang, melihat keluar ternyata Market Port of Stalwart dalam kebakaran, party pun berusaha membantu warga memadamkan api. Setelah memadamkan api Party mencoba melanjutkan perjalanan ke House Of Silence, hingga mereka dicegat oleh tentara Stalwart yang berada di dekat Tunnel of Grim dan diminta untuk membayar untuk bisa melanjutkan perjalanan, Party berusaha untuk bluff dan persuade para tentara hingga Party mengatakan kalau mereka baru saja menjual pakaian yang dijahit oleh [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}). Para tentara menganggap kalau mereka adalah Fremen dan menyerang mereka. Party pun mengakhiri perjalanan disana.

Party kemudian terbangun ke Fugue Plane, yaitu tempat kuasa [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}}) dan [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}}) mengatakan kalau mereka akan dibangkitkan dengan syarat yaitu *"Menjaga Keseimbangan Multiverse"* kemudian party terbangun didekat [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) di House of Silence.

## Key Learnings

- Party di pungli oleh tentara Stalwart di dekat Tunnel of Grim.
- Party diminta untuk Menjaga Keseimbangan Multiverse oleh [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}})
 
## Who Did They Meet?
 
- Tentara Stalwart di dekat Tunnel of Grim
- [The Lord of the Dead]({{< relref "faerunian-kelemvor-scag" >}})
- [Jergal]({{< relref "faerunian-jergal-scag" >}})
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
 
## Items Of Importance
 
- Identify item: Cincin +1 Dex Saves ([Gwyn]({{< relref "gwyn" >}}))

## What Worked 
 
-

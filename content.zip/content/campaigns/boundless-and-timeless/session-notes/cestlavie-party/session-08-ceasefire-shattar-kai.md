---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
- **[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock.
- **[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 
- **[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk.
- [Jeno]({{< relref "jeno" >}}). The Wizard
- [Klir]({{< relref "klir" >}}). The Rogue.
 
## Session Overview 
 
Party terbangun di ruang tamu House of Silence dan mendengar gerumuh suara antar perwakilan [Stalwart]({{< relref "stalwart" >}}) & [Fremen]({{< relref "fremen" >}}) dengan [Father Malen]({{< relref "father-malen" >}}) & [Damian]({{< relref "damian-the-squeeky-devils" >}}). [Damian]({{< relref "damian-the-squeeky-devils" >}}) datang dan menghampiri para party untuk mempersiapkan diri menemui para petinggi di Shattar-Kai dan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) menyerahkan tugas kedamaian kepada Party. Party dan [Father Malen]({{< relref "father-malen" >}}) merancang perjanjian gencatan senjata dan salah satu perwakilan Party menjadi perwakilan dalam surat perjanjian itu yang juga ditanda tangani oleh pihak [Stalwart]({{< relref "stalwart" >}}), [Fremen]({{< relref "fremen" >}}), dan [Father Malen]({{< relref "father-malen" >}}).

Party kemudian mencoba mendatangi [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) yang menunggu di Kapal Pequod untuk bertanya lebih lanjut kepada [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).

## Key Learnings

- Party & [Father Malen]({{< relref "father-malen" >}}) membuat perjanjian gencatan senjata antar [Stalwart]({{< relref "stalwart" >}}) & [Fremen]({{< relref "fremen" >}}). Party (Bureau) dan House of Silence sebagai pengawas gencatan senjata dan menggunakan [Geas]({{< relref "geas" >}}) untuk mengikat sumpah itu. Perjanjian Gencatan Senjata di tandatangani oleh Envoy Valtan, Envoy Meier, [Father Malen]({{< relref "father-malen" >}}) & [Alizar Valts]({{< relref "alizar-valts" >}}) sebagai perwakilan party.
- Gencatan senjata akan berlangsung selama 3 Hari 3 Malam dan di akhir waktu perwakilan [Tempus]({{< relref "forgotten-realms-tempus" >}}) akan membuat aturan-aturan perang antar [Stalwart]({{< relref "stalwart" >}}) & [Fremen]({{< relref "fremen" >}}).
- Envoy Valtan dari [Stalwart]({{< relref "stalwart" >}}) menawarkan kerja sama dengan Party (sebagai perwakilan Bureau).
- Edwin Kevinson mengkoleksi pakaian-pakaian yang pernah dijahit oleh [Father Malen]({{< relref "father-malen" >}}) & [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}). Dia tinggal di Port of Stalwart.
- [Father Malen]({{< relref "father-malen" >}}) adalah guru penjahit si [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}).
 
## Who Did They Meet?
 
- Envoy Valtan (Adik [General Valtan]({{< relref "general-valtan" >}}))
- Envoy Meier of [Fremen]({{< relref "fremen" >}}) the Firebanner 
- [Father Malen]({{< relref "father-malen" >}})
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
- Ishmael.
- Messenger dari Envoy Valtan
 
## Items Of Importance
 
- Identify Item; Amulet Kelemvor = +1 Wisdom Saves ([Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}})).
- Stalwart Pass.
- Sobekan baju milik [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) yang disobek oleh [Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).

## What Worked 
 - Mencoba untuk mengajak pihak [Stalwart]({{< relref "stalwart" >}}) & [Fremen]({{< relref "fremen" >}}) untuk gencatan senjata.

---
tags: [timeline, SessionJournals]
---

## Characters 
 
**[Gwyn]({{< relref "gwyn" >}})**. The Paladin 
 
**[Ashenka Roïs]({{< relref "ashenka-roïs" >}}).** The Monk. 
 
**[Alizar Valts]({{< relref "alizar-valts" >}}).** The Fighter. 

Away:
**[Meows Whiskerpop (Whisky)]({{< relref "meows-whiskerpop-whisky" >}}).** The Warlock. 
 
## Session Overview 
 
Party menuju Plane Earth pada lokasi Verdant Maw dan menghadap penjaga yang sedang menjaga Verdant Maw. Mereka berhasil melarikan diri dari penjaga dengan membawa artifak yang diminta oleh sang Bureau.

## Key Learnings

- Mempertanyakan tujuan Bureau mengirimkan petualang ke Verdant's
- Agent Bureau yang membangkan akan dikirimkan pendidik oleh Bureau.
- Bertemu dengan pekerja kontrak #666.
- Siapa Awanama ?
 
## Who Did They Meet?
 
**[Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).** Bertemu di depan Verdant's Maw. 
 
**[Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}).** Membawa ke Grand Library. 
 
**[Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}}).** Description 
 
**Professor Rumba.** Description 

**Ishmael**. Communicator Pekerja Kontrak #777 dengan Bureau

**Captain Ahab**. Nahkoda kapal Pequod ([Space Galleon]({{< relref "03playerloghandoutsmechanicsclivehiclesspace-galleon-aag" >}}))
 
## Items Of Importance
 
- Setiap player dapet magic item.
- Player mendapatkan [Space Galleon]({{< relref "03playerloghandoutsmechanicsclivehiclesspace-galleon-aag" >}}) bernama Pequod.

## What Worked 
 
- Memotong anggota tubuh party dapat mengembalikan tubuhnya jika diberikan kepada Ishmael.

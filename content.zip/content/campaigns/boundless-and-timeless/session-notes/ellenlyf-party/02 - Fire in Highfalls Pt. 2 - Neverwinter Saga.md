---
tags: [timeline, SessionJournals]
---

## Characters 
 
- **[Froggo]({{< relref "froggo" >}}).**
- **[Kairos]({{< relref "kairos" >}}).**
- **[Verdian Suyanti]({{< relref "verdian-suyanti" >}}).**
- [Minerva]({{< relref "minerva" >}}).
- [Sephire]({{< relref "sephire" >}}).

Away:
- [GomuGomuNo]({{< relref "gomugomuno" >}})
 
## Session Overview 
 
Para party mendapatkan surat yang menjanjikan "*Petualangan Luar Biasa, Harta Fantastis. Temukan Aku di Lonesome Tavern*" Surat itu memberikan instruksi yang amat sangat kurang jelas akhirnya para party mencoba mencari arah di desa Highfalls yang dekat dengan sumber air Saratoga. Ketika sedang mencari informasi ternyata Highfalls tiba-tiba diserang oleh pasukan Zariel yang dipimpin oleh [Komandan]({{< relref "barbed-devil" >}}) dengan cara membakar habis Highfalls dan menyurutkan sungai yang melewati Highfalls. Party pun membantu penduduk desa dan mengembalikan air yang tengah dibendung oleh para pasukan [Komandan]({{< relref "barbed-devil" >}}) yang diutus oleh Zariel. 

## Key Learnings

- Pasukan Zariel berusaha untuk mengambil alih Highfalls dengan membumi hanguskan rumah-rumah penduduk.
- Party berhasil mengalahkan pasukan Zariel dan mengetahui jalan tercepat menuju Lonesome Tavern.
- Party berhasil datang ke Highfalls
 
## Who Did They Meet?
 
- **Kepala Desa Highfalls.** Seorang [Cleric]({{< relref "cleric" >}}) dewa [Tyr]({{< relref "forgotten-realms-tyr" >}}) yang juga menjadi Kepala Desa di Highfalls.
 
- **Komandan.** Keturunan [Barbed Devil]({{< relref "barbed-devil" >}}) yang diutus oleh [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) untuk mengambil alih Highfalls.
 
- **[Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}).** Seorang pria yang menyambut para party di Lonesome Tavern.

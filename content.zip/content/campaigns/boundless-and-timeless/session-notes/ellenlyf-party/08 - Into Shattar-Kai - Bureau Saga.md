---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin / Warlock
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 
- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger.
- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard.

## Session Overview 
 
Party mendapatkan tugas untuk mencari artifact di plane Shattar-Kai. Mereka diinformasikan kalau sedang ada perang di Shattar-Kai, perang antar Stalwart dan Fremen. Party ditugaskan bersamaan dengan Diplomat yang dikirim Bureau yang akan bertemu di Port of Stalwart. Setelah beberapa saat menjelajah Shattar-Kai party bertemu dengan tentara Stalwart yang meminta "Sumbangan" kepada para party di dekat Tunnel of Grim. Para Party menolak memberikan sumbangan kemudian [Kairos]({{< relref "kairos" >}}) di panah jauh oleh tentara kemudian party mencoba untuk bersembunyi tetapi [Sephire]({{< relref "sephire" >}}) gagal untuk bersembunyi kemudian diajak oleh tentara Stalwart ke Tunnel Of Grim.

## Key Learnings

- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) adalah Diplomat yang dikirimkan oleh Bureau.
- Sedang terjadi perang antar Stalwart & Fremen. Setiap pekan setidaknya terjadi 1 agresi.
- Stalwart membuka rekrutmen tentara di Bastion of Stalwart.
- Fremen menyerang karavan di jalan Stalwart ?
- Mercenary Guild berada di Bastion of Stalwart
- House of Fisher adalah nelayan Orc yang menyediakan perikanan kepada Stalwart & Fremen.
- [Sephire]({{< relref "sephire" >}}) dibawa oleh tentara Stalwart ke Tunnel of Grim untuk dipekerjakan.
 
## Who Did They Meet?
 
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).
- Miril the Mercenary.
- Innkeeper Port of Stalwart.

## Items Of Importance
 
- 

## What Worked 
-

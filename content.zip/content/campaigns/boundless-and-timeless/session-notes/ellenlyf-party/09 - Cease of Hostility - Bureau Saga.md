---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin / Warlock
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 
- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger.
- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard.

## Session Overview 
 
Party melanjutkan perjalanan ke House of Silence setelah [Sephire]({{< relref "sephire" >}}) dibawa oleh tentara Stalwart ke Tunnel of Grim. Mereka mendatangi House Of Silence yang dimana banyak sekali batu nisan dan ada juga plakat yang bertulikan "Korban Perang" dan di dekat pintu benteng House of Silence party dinanti [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) dan diberitahu kalau besok Party dan [Father Malen]({{< relref "father-malen" >}}) dari House of Silence akan menemui perwakilan dari Stalwart dan Fremen. Disana Party, [Father Malen]({{< relref "father-malen" >}}), [Stalwart]({{< relref "stalwart" >}}), dan [Fremen]({{< relref "fremen" >}}) membuat kesepakatan gencatan senjata yang akan berlangsung selama 3 hari 3 malam dan di hari ke setelah gencatan senjata selesai para perwakilan dari [The Lord of Battles]({{< relref "faerunian-tempus-scag" >}}) akan datang dan para perwakilan [Stalwart]({{< relref "stalwart" >}}) & [Fremen]({{< relref "fremen" >}}) diminta oleh [Father Malen]({{< relref "father-malen" >}}) untuk membahas perjanjian kedamaian antar dua pihak. Party sebagai perwakilan Bureau of Time and Plane juga akan berusaha menginfluence para seluruh pihak untuk mau berdamai di waktu gencatan senjata ini.

Di sisi [Sephire]({{< relref "sephire" >}}) yang dipaksa untuk menambang di Tunnel of Grim dia bertemu dengan orang tua (human) yang membagikan makanannya dengan [Sephire]({{< relref "sephire" >}}) dan membagikan kisahnya bagaimana dia ada di Tunnel of Grim.

## Key Learnings

- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) menyerahkan tugas diplomat kepada Party.
- Perjanjian gencatan senjata dilengkapi dengan [Geas]({{< relref "geas" >}}). dari Party yang menandatangani adalah [Kairos]({{< relref "kairos" >}}).
- [Sephire]({{< relref "sephire" >}}) mendengar dari orang tua kalau kelompok [Fremen]({{< relref "fremen" >}}) di Tunnel of Grim sedang membuat rencana untuk kabur dari Tunnel of Grim.
 
## Who Did They Meet?
 
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).
- [Father Malen]({{< relref "father-malen" >}}).
- Envoy Valtan of Stalwart.
- Envoy Meier of Fremen Firebanner.
- Orangtua di Tunnel of Grim

## Items Of Importance
 
- Gelang yang dipakai [Sephire]({{< relref "sephire" >}}) selama di Tunnel of Grim.

## What Worked 
-

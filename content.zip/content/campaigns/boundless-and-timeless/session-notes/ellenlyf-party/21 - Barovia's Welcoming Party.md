---
tags:
  - timeline
  - SessionJournals
---
<div
  class='ob-timelines'
  data-date='144-43-49-00'
  data-title='dd-mm-yyy desc'
  data-class='orange'
  data-img = '\z_Assets\ImagePlaceholder.png'
  data-type='range'
  data-end="2000-10-20-00">
  Warm Greetings from Barovia
</div>

## Characters 
 
- **[[Sephire]]** — Oath of Vengeance Paladin | The Fiend Warlock  
- **[[Minerva]]** — Circle of Stars Druid | Life Domain Cleric
- **[[Froggo]]** — Gloom Stalker Ranger  | Rogue
- **[[Verdian Suyanti]]** — College of Glamour Bard
- **[[Kairos]]** — Soulknife Rogue
- **[[Asep]]** — Battle Smith Artificer | Bladesinging Wizard
 
## Session Overview 
 
It's all started while the party is about to go to their ships in [[Grand Library]]'s Space Port, [[The Daughter|Elira]] approach [[Sephire]] and giving him cookies that shaped like [[Ellenlyf]] Party.
After that cookies the party goes to Pequod their ships then coordinate with Ishmael and Ahab to go to Plane of Dread where Boravia reside.
When Pequod getting closer to the plane of dread the crew saw that a moon with bright light shining the plane, the crew tried to understands it they only know that this satellite is shaped like stones with light grey colour. Ishmael instruct that Pequod will be landing on Lake Zarovich then the crew proceed.
When arriving at Lake Zarovich, crew watching an elf woman running toward the lake to the ships by the looks of it she seems to need help, [[Minerva]] instantly helped her then she swam to her. The rest of the crew still understanding what is she running from then they decide to go after [[Minerva]]. Then when the party already at the Lake Zarovich's Shore creatures that chasing this elf woman appears then combat follows.

[[Ellenlyf]] party barely beating this creature and then Ishmael get to them in his boat to get all of them back to Pequod. While everyone in Pequod this Elf Woman introduce herself as Bureau Agent, her codename is [[HAWA]].


## Key Learnings

- There is a moon that are orbiting the planet and the moon shining Plane of Dread. Source of the moon is currently unknown.
- When Pequod landing all the crew watching [[HAWA]] tried to outrun something that chases her around Lake Zarovich Area.
- Party barely beating creatures that chasing [[HAWA]] in Lake Zarovich area ([[Froggo]] & [[Verdian Suyanti]] died. But [[revivify]] afterward by [[Minerva]]) 
 
## Who Did They Meet?
 
- **[[The Daughter|Elira]]**. Gave [[Sephire]] cookie that shaped like the party.
 
- **[[HAWA]].** Meet with the players when the ships just landed. 
 
## Items Of Importance
 
- **[[The Daughter|Elira]]**'s cookies that shaped like the party 

## What Worked 
 
- 

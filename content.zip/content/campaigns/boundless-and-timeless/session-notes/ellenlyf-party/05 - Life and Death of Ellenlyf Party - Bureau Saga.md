---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin 
 
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 

- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger

- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard

Away:
**[GomuGomuNo]({{< relref "gomugomuno" >}}).** The Monk. 
 
## Session Overview 
 
Party mendapat ultimatum untuk mengembalikan cincin dengan batu ruby kepada perempuan yang memilik rambut setengah gelap dan setengah terang dalam kurun waktu 24 jam. Party berhasil menemui [Aldric]({{< relref "the-paladin" >}}) dan [Putrinya]({{< relref "the-daughter" >}}) yang sedang berada di Benteng Caerthwyn. [Aldric]({{< relref "the-paladin" >}}) berkata pada Party bahwa dia tahu apa tujuan mereka kesini dan mengatakan bahwa artifact nya dekat dan akan memberikannya jika mereka mau menjaga putrinya selama 4 hari dan dia meninggalkan party dan putrinya untuk memanggil bantuan. Ternyata dalam kurun waktu 24 jam party gagal mengembalikan cincin kepada orang yang dimaksud oleh [Shadowy Figures]({{< relref "the-mother" >}}) dan akhirnya saat Party tidur terlelap tidur mereka diserang oleh pasukan [Shadowy Figures]({{< relref "the-mother" >}}) hingga berakhir pada kematian para Party.

Party kemudian terbangun di Fugue Plane dan bertemu dengan [The Lord of the Dead]({{< relref "faerunian-kelemvor-scag" >}}) dan [The Final Scribe]({{< relref "faerunian-jergal-scag" >}}). Mereka mengingatkan mereka bahwa mereka tahu bahwa ada tidak keseimbangan yang dimana [The Final Scribe]({{< relref "faerunian-jergal-scag" >}}) menyebut *"Baik dan Jahat harus memiliki keseimbangan, mereka yang Ingin Hidup Beraturan dan mereka yang Ingin Hidup Bebas harus memiliki keseimbangan. Dan keseimbangan itupun kini tengah terganggu"* [The Lord of the Dead]({{< relref "faerunian-kelemvor-scag" >}}) meminta kepada party untuk memastikan keseimbangan dengan artifact yang mereka temukan dan mengembalikan jiwa para Party menuju tubuhnya masing-masing yang sedang di jaga oleh [Damian]({{< relref "damian-the-squeeky-devils" >}}) di sisa reruntuhan Benteng Caerthwyn.

## Key Learnings

- Cincin Ruby yang ditemukan dimiliki oleh Wizard paling kuat di Aruendel yang dibuat 50 tahun yang lalu ?
- Setiap pagi sebelum matahari terbit selalu ada seorang perempuan yang data di kolam ikan di sisa rerunthuan Benteng Caerthwyn.
- [Aldric]({{< relref "the-paladin" >}}) berjualan roti bersama putrinya [Elira]({{< relref "the-daughter" >}}).
- Apakah [Shadowy Figures]({{< relref "the-mother" >}}) adalah ibu dari [Elira]({{< relref "the-daughter" >}}) atau istri [Aldric]({{< relref "the-paladin" >}}) ?
- [Elira]({{< relref "the-daughter" >}}) lahir sekitar 20 tahun yang lalu dan tragedi dimana para bangsawan yang menghabisi keluarga Pelgrane (Keluarga yang sekarang memegang tahta di Aruendel) dengan sihir terjadi dan berakhir tepat 33 tahun yang lalu.
- Artifact yang diminta oleh Bureau menahan efek-efek sihir yang tersisah 33 tahun yang lalu. Dan artifact ini di tandai dengan logo Bureau.
- Informasi dari [Damian]({{< relref "damian-the-squeeky-devils" >}}), [Elira]({{< relref "the-daughter" >}}) sedang dibawa oleh ibunya di Nyx's Ring. 
 
## Who Did They Meet?
 
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
- [Ser Aldric]({{< relref "the-paladin" >}})
- [Elira]({{< relref "the-daughter" >}}) putri [Ser Aldric]({{< relref "the-paladin" >}})
- Wujud asli [Shadowy Figures]({{< relref "the-mother" >}})
- [The Lord of the Dead]({{< relref "faerunian-kelemvor-scag" >}}) & [The Final Scribe]({{< relref "faerunian-jergal-scag" >}})

## Items Of Importance
 
- Terdapat pedang (Longsword) yang menancap di batu di sisa reruntuhan Benteng Caerthwyn. 

## What Worked

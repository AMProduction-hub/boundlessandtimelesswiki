---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})** — Paladin / Warlock  
- **[Minerva]({{< relref "minerva" >}})** — Circle of Stars Druid / Life Cleric  
- **[Froggo]({{< relref "froggo" >}})** — Gloomstalker Ranger  

### Away
- **[Verdian Suyanti]({{< relref "verdian-suyanti" >}})** — Bard  
- **[Kairos]({{< relref "kairos" >}})** — Soulknife Rogue  

## Session Overview

[Minerva]({{< relref "minerva" >}}), [Sephire]({{< relref "sephire" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) tiba di No Man’s Land yang diselimuti kabut tebal. Mereka bergabung dengan caravan [Fremen]({{< relref "fremen" >}}) menuju secret base, di mana [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) dan para petinggi [Fremen]({{< relref "fremen" >}}) merencanakan serangan ke Bastion of [Stalwart]({{< relref "stalwart" >}}) pada pukul 02.00. Mengetahui [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) masih di Bastion, party meminta waktu untuk menghubungi mereka. [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) memberi sebuah scroll of [Sending]({{< relref "sending" >}}), lalu party menuju House of Silence.  

Sementara itu, [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) tiba di Tunnel of Grim, menyaksikan persiapan militer [Stalwart]({{< relref "stalwart" >}}) dan banyak wizard bekerja. Mereka bertemu [General Valtan]({{< relref "general-valtan" >}}), yang menjelaskan bahwa artifact dari koloni pertama Shattar-Kai akan digunakan untuk melarikan diri bila [Stalwart]({{< relref "stalwart" >}}) kalah. [Damian]({{< relref "damian-the-squeeky-devils" >}}) muncul, menjelaskan asal-usul artifact Netheril dan mengingatkan bahwa tugas Bureau adalah mengambilnya, bukan mencampuri perang. [Froggo]({{< relref "froggo" >}}) & [General Valtan]({{< relref "general-valtan" >}}) sepakat mendukung [Stalwart]({{< relref "stalwart" >}}), meski Damian memperingatkan hal itu di luar mandat Bureau.  

Masuk lebih dalam, [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) menemukan reruntuhan yang tak bisa digali sihir arcane karena dilindungi divine magic. Dengan pickaxe, [Froggo]({{< relref "froggo" >}}) berhasil menembus salah satu batu, memberi celah para wizard untuk menyelidiki lebih lanjut.  

Di House of Silence, [Minerva]({{< relref "minerva" >}}), [Sephire]({{< relref "sephire" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) bertemu [Father Malen]({{< relref "father-malen" >}}), yang mengabarkan [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) sudah ke Tunnel of Grim. Mereka lalu menuju Bastion of [Stalwart]({{< relref "stalwart" >}}), yang kini terisolasi ketat. Dengan penyamaran pakaian House of Silence, mereka berhasil masuk area stable. Saat menyelidiki rumah [Father Malen]({{< relref "father-malen" >}}), mereka menemukan pakaian mewah, lukisan keluarga, dan sebuah lukisan kecil dirinya bersama [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}).  

## Key Learnings

- [Fremen]({{< relref "fremen" >}}) berencana mengepung Bastion of [Stalwart]({{< relref "stalwart" >}}); bila infiltrasi gagal, mereka akan meledakkan tembok.  
- [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) melihat petinggi [Stalwart]({{< relref "stalwart" >}}) di Tunnel of Grim, menemukan reruntuhan dilindungi divine magic (Neutral).  
- Artifact adalah pecahan Netheril, terkait Karsus’s Folly. Dulu hendak dipakai avatar [Bane]({{< relref "faerunian-bane-scag" >}}) untuk mengguncang keseimbangan kosmos, namun gagal dan jatuh, membentuk Tunnel of Grim.  
- [Stalwart]({{< relref "stalwart" >}}) berencana memakai artifact untuk melarikan diri bila kalah perang.  
- Bastion kini ditutup ketat; kualitas seragam prajurit menurun.  
- Rumah [Father Malen]({{< relref "father-malen" >}}) menyimpan pakaian bagus, armor beremblem [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}}), dan lukisan dirinya dengan [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}).  
- Pada pukul 02.00, pasukan [Fremen]({{< relref "fremen" >}}) mulai bersiap di sekitar Bastion.  

## Who Did They Meet?

- [Father Malen]({{< relref "father-malen" >}})  
- [General Valtan]({{< relref "general-valtan" >}})  
- Petinggi [Stalwart]({{< relref "stalwart" >}}) & [Fremen]({{< relref "fremen" >}})  
- [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}})  
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})  
- Calyan of Fremen Fire Banner  
- Arch-Wizard & Wizards [Stalwart]({{< relref "stalwart" >}})  
- Shadow Arch Druid (sekutu [Fremen]({{< relref "fremen" >}}))  

## Items Of Importance

- Scroll of [Sending]({{< relref "sending" >}}) dari [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}})  
- Pakaian House of Silence untuk penyamaran  
- Pakaian mewah & lukisan keluarga di rumah [Father Malen]({{< relref "father-malen" >}})  
- Full [Plate Armor]({{< relref "plate-armor" >}}) beremblem [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}})  

## What Worked

- Pickaxe [Froggo]({{< relref "froggo" >}}) berhasil menembus reruntuhan yang dilindungi divine magic di Tunnel of Grim.

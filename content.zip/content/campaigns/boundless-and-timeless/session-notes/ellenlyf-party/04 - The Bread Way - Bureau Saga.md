---
tags: [timeline, SessionJournals]
---
## Characters 
 
**[Sephire]({{< relref "sephire" >}})**. The Paladin 
 
**[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
 
**[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 

[Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger

[Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard

Away:
**[GomuGomuNo]({{< relref "gomugomuno" >}}).** The Warlock. 
 
## Session Overview 
 
Party menuju Plane Aruendel yang jauh di Far Realm untuk mencari Sir Aldric yang merupakan mantan agent Bureau yang sedang melindungi artifak yang dicari oleh Bureau.

## Key Learnings

- Aldric biasanya lewat Moondell Valley, Brindlewatch, Benteng Caerthwyn.
- Menemukan cincin yang memiliki ruby dan catatan bertuliskan "Aku selalu bersamamu dari jauh, buah hatiku. ~ Sang Ibu".
- Mengetahui penyebab utama reruntuhkan di Jalan Tua Pelgrane.
 
## Who Did They Meet?
 
- Bartender Brindlewatch
- Kawan lama Aldric ?
 
## Items Of Importance
 
- Party PC mendapatkan Thieves Tools.
- Player mendapatkan Amulet bangsawan yang sekarang memegang kerajaan.
- Mendapatkan cincin ruby yang ada tulisan dari Sang Ibu.

## What Worked 
 
- Berhasil menjual Goodberry ke Bartender Brindlewatch.

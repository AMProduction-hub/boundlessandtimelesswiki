---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin / Warlock
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 
- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger.
- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard.

## Session Overview 
 
[Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) mencoba menyelidiki kematian Envoy Valtan di gedung administrasi [Stalwart]({{< relref "stalwart" >}}). Penjaga gedung mengarahkan [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) untuk menemui keponakan Envoy Valtan di ruangan Menteri Pariwisata. Saat [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) memasuki ruangan Menteri Pariwisata, mereka disambut oleh [Eric Valtan]({{< relref "eric-valtan" >}}) disana [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) mencoba mencari tahu tentang kematian Envoy Valtan. Party diberitahu bahwa di dalam gedung ini ada ruangan envoy valtan, ruang otopsi, ruang menteri-menteri, ballroom, dan war room. [Kairos]({{< relref "kairos" >}}) & [Froggo]({{< relref "froggo" >}}) mencoba memasuki ruang otopsi untuk menyelidiki mayat Envoy Valtan. Dari penyelidikan mereka, didapati bahwa bola mata Envoy Valtan berubah menjadi ungu dan tidak ditemukannya luka atau semacamnya disekitarnya. Akhirnya [Kairos]({{< relref "kairos" >}}) & [Froggo]({{< relref "froggo" >}}) mencoba untuk berbicara kepada [General Valtan]({{< relref "general-valtan" >}}) di dalam War Room.

[Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) mengirim barang menuju [Fremen]({{< relref "fremen" >}}), disaat di tengah No Man's Land yang penuh dengan kabut [Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) diberhentikan oleh beberapa orang [Fremen]({{< relref "fremen" >}}) dan mengatakan kalau barang ini akan diberikan kepada mereka. Disaat itu, para [Fremen]({{< relref "fremen" >}}) menawarkan tambahan uang jika [Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) mau membantu mengirim barang ini menuju Tunnel of Grim yang dimana tawaran itu diterima oleh Party. Akhirnya party diajak beristirahat di secret base [Fremen]({{< relref "fremen" >}}) di No Man's Land untuk beristirahat dan sebagian dari mereka menyamar menjadi tentara [Stalwart]({{< relref "stalwart" >}}) bersama party menuju Tunnel of Grim.

[Sephire]({{< relref "sephire" >}}) yang masih menetap di Tunnel of Grim tiba-tiba mendengar ada suara keributan di dalam gua, tak lama kemudian tiba-tiba ada ledakan besar yang mengguncangkan gua. [Sephire]({{< relref "sephire" >}}) didatangi oleh orang tua dan mengajak [Sephire]({{< relref "sephire" >}}) menuju keluar didalam keributan, di dalam keributan [Sephire]({{< relref "sephire" >}}) berhasil menawan salah satu penjaga. Ketika [Sephire]({{< relref "sephire" >}}) dan orang tua menuju keluar gua dari luar sudah banyak penjaga-penjaga mengambil posisi untuk menembakkan anak panah ke arah [Sephire]({{< relref "sephire" >}}) dan disinilah diantara mereka sedang standoff dimana penjaga yang menjadi tawanan [Sephire]({{< relref "sephire" >}}) menjadi human shield, [Sephire]({{< relref "sephire" >}}) pun mencoba bernegosiasi dengan penjaga untuk mengetahui dimana barang-barang milik [Sephire]({{< relref "sephire" >}}) disimpan. Tak lama kemudian ledakan hebat menyusul dan mengguncang seluruh pihak tetapi [Sephire]({{< relref "sephire" >}}) dan orang tua berhasil kabur di kesempatan itu dan bertemu dengan [Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). Disini sisa Party berniat menuju [Fremen]({{< relref "fremen" >}}) Camp dan berpisah dengan orang tua yang membantu [Sephire]({{< relref "sephire" >}}) keluar. Party pun datang di [Fremen]({{< relref "fremen" >}}) Camp dan bertemu dengan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}).

[Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) yang masih di Bastion of [Stalwart]({{< relref "stalwart" >}}) di pagi hari, mendengar adanya ledakan hebat di Tunnel Of Grim tak begitu lama party melihat [General Valtan]({{< relref "general-valtan" >}}) dan beberapa rombongan orang berjalan cepat memasuki gedung administrasi [Stalwart]({{< relref "stalwart" >}}) di rombongan itu [Kairos]({{< relref "kairos" >}}) berhasil menyelip masuk kedalam war room. Kemudian [General Valtan]({{< relref "general-valtan" >}}) memulai pembicaraan dengan "Bagaimana kita akan mengakhiri perang ini ?".

## Key Learnings

- Barang yang dikirim oleh [Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) adalah Bubuk Mesiu.
- Envoy Valtan mati karena sihir Enhancement.
- [Stalwart]({{< relref "stalwart" >}}) mempersiapkan perang dengan [Fremen]({{< relref "fremen" >}}).
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) kenal baik dengan [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) ?
- [Eric Valtan]({{< relref "eric-valtan" >}}) adalah anak dari [General Valtan]({{< relref "general-valtan" >}}).
- Orang tua yang membantu [Sephire]({{< relref "sephire" >}}) pergi menuju Port of Stalwart.
 
## Who Did They Meet?
 
- Spesialis Otopsi [Stalwart]({{< relref "stalwart" >}})
- [Eric Valtan]({{< relref "eric-valtan" >}})
- [General Valtan]({{< relref "general-valtan" >}})
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}})
- [Fremen]({{< relref "fremen" >}})
- Orang Tua yang membantu [Sephire]({{< relref "sephire" >}})

## Items Of Importance
 
- 

## What Worked 
-

## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin / Warlock
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 
- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger.
- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard.

## Session Overview 
 
Party memulai perjalanan dengan mencari informasi kepada para perwakilan-perwakilan [Fremen]({{< relref "fremen" >}}) dan [Stalwart]({{< relref "stalwart" >}}) yang ada di House of Silence. Party mendapat tawaran untuk bekerja sama dengan [Stalwart]({{< relref "stalwart" >}}) dan diberi [Stalwart]({{< relref "stalwart" >}}) Pass oleh Envoy Valtan. Kemudian party mencoba berkomunikasi dengan perwakilan [Fremen]({{< relref "fremen" >}}) dan mendengar proposal perdamaian dari mereka. Kemudian party mencoba bertemu dengan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) untuk berkomunikasi dengan masalah yang sedang dihadapi. Party pun mencoba mencari informasi mengenai batu artefact itu kepada [Father Malen]({{< relref "father-malen" >}}) dengan jawaban bahwa [Father Malen]({{< relref "father-malen" >}}) tidak mengetahui batu itu. 

Party kemudian melanjutkan perjalanan ke Bastion Of [Stalwart]({{< relref "stalwart" >}}) dan ketika datang mereka diinformasikan kalau Envoy Valtan barusan saja meninggal. Party pun mencoba mengelilingi kota Bastion of [Stalwart]({{< relref "stalwart" >}}). Hingga Party bertemu dengan Innkeeper yang merupakan penyelundup Tunnel of Grim dan dia menawarkan pekerjaan kepada Party untuk mengirimkan barang ke [Fremen]({{< relref "fremen" >}}) dengan kereta kuda. Disini Party mulai berpisah, [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) mencoba menyelidiki pembunuhan Envoy Valtan, [Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) mengirimkan barang ke [Fremen]({{< relref "fremen" >}}), dan [Sephire]({{< relref "sephire" >}}) yang masih tetap di Tunnel of Grim.

## Key Learnings

- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) memberi party 3 pertanyaan, yang 2 dijawab benar, 1 dijawab salah.
- [Fremen]({{< relref "fremen" >}}) mungkin akan memperbolehkan bekerja sama dengan [Stalwart]({{< relref "stalwart" >}}) jika [Stalwart]({{< relref "stalwart" >}}) mau membahasnya. Tetapi dengan proposal; Bastion of [Stalwart]({{< relref "stalwart" >}}) menjadi pusat pemerintahan [Fremen]({{< relref "fremen" >}}).
- Envoy Valtan mati.
- [General Valtan]({{< relref "general-valtan" >}}) memiliki anak yang belum menikah ?
- [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) mencoba menyelidiki kematian Envoy Valtan.
- [Minerva]({{< relref "minerva" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) mengirim perlengkapan-perlengkapan untuk [Fremen]({{< relref "fremen" >}}) dengan kereta kuda yang ditugaskan oleh Innkeeper di Inn yang ada di Bastion of Stalwart.
- [Sephire]({{< relref "sephire" >}}) mendapat informasi kalau bahan-bahan sedang dikirim untuk dapat lolos dari Tunnel of Grim.
 
## Who Did They Meet?
 
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
- [Father Malen]({{< relref "father-malen" >}})
- Envoy Valtan
- Envoy Meier
- Innkeeper Inn Bastion of Stalwart.

## Items Of Importance
 
- Terdapat Longbow di Blacksmith Bastion of Stalwart (Longbow + 2 + 1 Acid)

## What Worked 
- Menyanyi di Inn membuat kekacauan ?

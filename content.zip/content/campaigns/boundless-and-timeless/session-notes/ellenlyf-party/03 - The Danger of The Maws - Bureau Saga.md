---
tags: [timeline, SessionJournals]
---
## Characters 
 
**[Sephire]({{< relref "sephire" >}})**. The Paladin 
 
**[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
 
**[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 

[Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger

[Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard

Away:
**[GomuGomuNo]({{< relref "gomugomuno" >}}).** The Warlock. 
 
## Session Overview 
 
Party menuju Plane Earth pada lokasi Verdant Maw dan menghadap penjaga yang sedang menjaga Verdant Maw. Mereka berhasil melarikan diri dari penjaga dengan membawa artifak yang diminta oleh sang Bureau.

## Key Learnings

- Verdant's Maw adalah dungeon yang memberi rasa rakus kepada para petualang yang memasukinya.
- Adanya Ekspedisi yang memasuki Verdant Maw sebelum party Ellenlyf.
- Bertemu dengan pekerja kontrak #666 Damian, seorang cambion.
 
## Who Did They Meet?
 
**[Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).** Bertemu di depan Verdant's Maw. 
 
**[Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}).** Membawa ke Grand Library. 
 
**[Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}}).** Description 
 
**Professor Rumba.** Description 

**Ishmael**. Communicator Pekerja Kontrak #777 dengan Bureau

**Captain Ahab**. Nahkoda kapal Pequod ([Space Galleon]({{< relref "03playerloghandoutsmechanicsclivehiclesspace-galleon-aag" >}}))
 
## Items Of Importance
 
- Setiap player dapet magic item (+1).
- Player mendapatkan [Space Galleon]({{< relref "03playerloghandoutsmechanicsclivehiclesspace-galleon-aag" >}}) bernama Pequod.
- Terdapat item-item relic historis Forgotten Realms yang ada pada Verdant Maw. Jika diambil sepertinya memberi kekuatan kepada penjaga Verdant Maw.

## What Worked 
 
- Ishmael dapat menghidupkan kembali anggota party yang mati dengan perlu membawa mayat anggota party.

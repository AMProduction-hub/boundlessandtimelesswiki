---
tags: [timeline, SessionJournals]
---
![](ellenlyf_1.png)
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})** — [Oath of Vengeance]({{< relref "paladin-oath-of-vengeance" >}}) [Paladin]({{< relref "paladin" >}}) | [The Fiend]({{< relref "warlock-the-fiend" >}}) [Warlock]({{< relref "warlock" >}})  
- **[Minerva]({{< relref "minerva" >}})** — [Circle of Stars]({{< relref "druid-circle-of-stars-tce" >}}) [Druid]({{< relref "03playerloghandoutsmechanicscliclassesdruid" >}}) | [Life Domain]({{< relref "cleric-life-domain" >}}) [Cleric]({{< relref "cleric" >}})
- **[Froggo]({{< relref "froggo" >}})** — [Gloom Stalker]({{< relref "ranger-gloom-stalker-xge" >}}) [Ranger]({{< relref "03playerloghandoutsmechanicscliclassesranger" >}})  
- **[Verdian Suyanti]({{< relref "verdian-suyanti" >}})** — [College of Glamour]({{< relref "bard-college-of-glamour-xge" >}}) [Bard]({{< relref "bard" >}}) 
- **[Kairos]({{< relref "kairos" >}})** — [Soulknife]({{< relref "rogue-soulknife-tce" >}}) [Rogue]({{< relref "03playerloghandoutsmechanicscliclassesrogue" >}})
- Asep — [Battle Smith]({{< relref "artificer-battle-smith-tce" >}}) [Artificer]({{< relref "artificer-tce" >}}) | [Bladesinging]({{< relref "wizard-bladesinging-tce" >}}) [Wizard]({{< relref "wizard" >}})

## Session Overview

_"Invasi [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) telah tiba."_  
ucap [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).

Sebuah cahaya merah menembus langit Shattar-Kai, berasal dari House of Silence. Langit berubah menjadi merah, dan tanah diselimuti kegelapan. Dari langit mulai turun pasukan [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}).

Tak lama, [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) muncul membawa kabar bahwa benar — Zariel akan datang. Ia berusaha meminimalisir agar kekuatan Zariel tidak terwujud sepenuhnya. Di saat yang sama, [Asep]({{< relref "asep" >}}) keluar dari portal yang sama dan bergabung dengannya.

[Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) memanggil bala bantuan, dan datanglah **empat Musikus Waktu**. Bersama mereka, ia berangkat menuju House of Silence.  
[Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) memperingatkan party bahwa mereka akan segera menyaksikan sedikit dari kekuatan **Ao**, yang saat ini dipegang oleh Shaperite.

---

Damian kemudian berkata bahwa [Fremen]({{< relref "fremen" >}}) dan [Stalwart]({{< relref "stalwart" >}}) masih ada — mengapa tidak meminta bantuan mereka menghadapi invasi ini?  
Party pun membagi tugas:

- **Kelompok Fremen:** [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}), [Sephire]({{< relref "sephire" >}}), [Verdian Suyanti]({{< relref "verdian-suyanti" >}})
- **Kelompok Stalwart:** [Eric Valtan]({{< relref "eric-valtan" >}}), [Kairos]({{< relref "kairos" >}}), [Froggo]({{< relref "froggo" >}}), [Minerva]({{< relref "minerva" >}})

Party berhasil meyakinkan [General Valtan]({{< relref "general-valtan" >}}) dari Stalwart dan [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}}) dari Fremen untuk bekerja sama.  
Sebagai hasilnya, mereka memperoleh:

- **Dragon’s Fire** _(1x use)_
- **Stalwart’s Banner** _(+2 Save Throws)_

Selain itu, pasukan **[Fremen]({{< relref "fremen" >}})** akan membantu dengan serangan gerilya dan tembakan panah dari jauh. _(Setiap ranged attack yang miss dapat di-_reroll_ 1x per round)_.

Dalam perang nanti, **[Eric Valtan]({{< relref "eric-valtan" >}})** akan memimpin pasukan Stalwart, sedangkan **[Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}})** akan memimpin pasukan Fremen.  
Dengan demikian, party berhasil menyatukan dua kekuatan besar Shattar-Kai.

Ishmael juga menjelaskan bahwa kapal **Pequod** memiliki [Arcane Cannon]({{< relref "arcane-cannon-egw" >}}) _(Dex Save DC 15, 10d6 fire damage/round)_ dengan **3 amunisi** yang dapat digunakan party.

---

Sebelum berangkat menuju House of Silence, party beristirahat dan merencanakan tindakan mereka saat bertemu dengan [Father Malen]({{< relref "father-malen" >}}).

---

Keesokan harinya, mereka melihat **Wizard Stalwart** telah membuka portal untuk pasukan mereka menuju area House of Silence. Dari arah Fremen, pasukan gerilya juga mulai mendekat. Party pun bergegas ke sana untuk menghentikan **Father Malen** dan **Zariel**.

House of Silence kini dipenuhi pasukan Zariel, namun berkat bantuan Fremen dan Stalwart, jalan menuju katedral mulai terbuka. Di depan katedral itu berdirilah **Father Malen**.

> _"Kau sudah tahu ini adalah jalannya agar perang Fremen dan Stalwart bisa berakhir! Kau sudah melihat banyaknya pemakaman di luar! Aku telah kehilangan banyak! Jika kau ingin aku berhenti, majulah... dan lawan aku!"_  
> — [Father Malen]({{< relref "father-malen" >}})

---

Dalam pertempuran, Father Malen memegang **staf hitam bercabang** yang ujungnya tertanam **batu biru toska** — artefak yang dicari oleh Bureau of Time and Plane.

Setiap kali Father Malen mengetukkan stafnya, cahaya biru toska menyebar seperti gelombang. Ia mengetukkan tiga kali — dan seketika cahaya di langit berubah makin merah. Di saat bersamaan, **Shaperite** yang terbang di langit tersambar **petir putih**, membuatnya jatuh. Katedral House of Silence pun runtuh, dan dari reruntuhan muncul **Avatar of Zariel**.

Pertempuran sengit pun terjadi.  
Akhirnya, [Sephire]({{< relref "sephire" >}}) memberikan **final blow** ke arah kepala Avatar Zariel, membuat tubuh sang avatar memudar dan lenyap.

---

Setelah pertempuran, party menemukan **Father Malen** duduk bersila di reruntuhan. Ia sadar akan hukumannya oleh bangsa Shattar-Kai.  
[Eric Valtan]({{< relref "eric-valtan" >}}) dan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) datang, dan party menyerahkan keputusan hukuman kepada mereka.

Akhirnya, **Father Malen dijatuhi hukuman pengasingan**.

---

Kemudian party menemui kembali [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}). Ia meminta untuk melihat artefak yang telah mereka dapatkan, lalu berkata ada hal penting yang harus dibicarakan di atas **Pequod**.  
Party pun berangkat, meninggalkan Shattar-Kai yang kini disinari **Golden Hours**. Sebagian party beristirahat, sementara **Kairos** menemui Damian.

> _"Barusan kau saksikan sendiri — Ao dan para dewa telah melanggar perjanjian mereka: mereka tak boleh turun tangan langsung dalam urusan fana. Kau lihat bagaimana [Shaperite]({{< relref "shaperite-the-agent" >}}) diserang langsung oleh [Mystra]({{< relref "faerunian-mystra-scag" >}}), kehilangan satu mata dan satu tangan. Batu-batu yang kalian kumpulkan adalah batu yang akan digunakan Ao untuk **menyerap seluruh kekuatan para dewa dan dewi**. Mereka tahu hal itu... dan kini mereka mulai bergerak terang-terangan."_  
> — [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) kepada [Kairos]({{< relref "kairos" >}})

Kairos kemudian bertanya apa sebenarnya tujuan Damian.  
Damian menjawab:

> _"Jika aku memberitahumu sekarang... bukankah cerita ini akan berakhir terlalu cepat? Beristirahatlah, Kairos. Masih banyak hal yang harus kau lakukan setelah ini. Dan sepertinya... mulai sekarang, akulah orang yang paling dicari oleh Bureau."_

## Key Learnings

- [Father Malen]({{< relref "father-malen" >}}) yang mengendalikan artefact.
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dan [Eric Valtan]({{< relref "eric-valtan" >}}) teman semenjak kecil yang kemudian saling jatuh cinta.
- Party mempersatukan [Fremen]({{< relref "fremen" >}}) & [Stalwart]({{< relref "stalwart" >}}) untuk berperang melawan invasi [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarylegendary-groupzariel-mpmm" >}}) yang dipanggil oleh [Father Malen]({{< relref "father-malen" >}}).
- [Mystra]({{< relref "faerunian-mystra-scag" >}}) melemparkan sihir ke arah [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) yang membuatnya kehilangan tangan dan matanya. Informasi ini diberikan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).
- Ao dan Dewa-dewi melanggar perjanjian mereka untuk tidak mengurusi urusan fana secara langsung.
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) mengakatan kalau dirinya akan menjadi orang yang paling dicari oleh Bureau setelah ini.

## Who Did They Meet?

- [General Valtan]({{< relref "general-valtan" >}})  
- [Eric Valtan]({{< relref "eric-valtan" >}})
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}})
- [Nikael of Fire Banner]({{< relref "nikael-of-fire-banner" >}})
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
- [Father Malen]({{< relref "father-malen" >}})
- [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}})
- 4 Musikus Waktu
- Avatar [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) 
- Ishmael
- Ahab

## Items Of Importance

- Artifact Bureau berwarna Biru Toska

## What Worked

- Mencoba menyatukan [Fremen]({{< relref "fremen" >}}) dan [Stalwart]({{< relref "stalwart" >}}) melawan [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) yang dipanggil [Father Malen]({{< relref "father-malen" >}}).

---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin 
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 
- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger.
- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard.

Away:
**[GomuGomuNo]({{< relref "gomugomuno" >}}).** The Monk. 
 
## Session Overview 
 
Party mencoba mencegah penyerangan pasukan [Ser Aldric]({{< relref "the-paladin" >}}) menuju camp para Wizard di Nyx's Ring karena party berjanji kepada [Selaveth]({{< relref "the-mother" >}}) untuk membantunya melindungi dia dan [Elira]({{< relref "the-daughter" >}}) hingga pintu Nyx's Ring terbuka dan mereka bisa lewat dengan bayaran Artifact yang mereka cari selama ini. 

## Key Learnings

- [Selaveth]({{< relref "the-mother" >}}) selama ini dia bermuka dua kepada para Wizard bahwa Nyx's Ring akan terbuka dan memanggil entitas dari plane lain padahal Nyx's Ring akan membukakan pintu nya untuk menuju lokasi persembunyian [Selaveth]({{< relref "the-mother" >}}) di Astral Sea.
- [Ser Aldric]({{< relref "the-paladin" >}}) jika mati dalam peperangan ini dia akan naik menjadi [Celestial]({{< relref "celestial" >}}) di bawah deity yang tinggal di Mount Celestia.
 
## Who Did They Meet?
 
- [Ser Aldric]({{< relref "the-paladin" >}}).
- [Selaveth]({{< relref "the-mother" >}}).
- [Elira]({{< relref "the-daughter" >}}).
- Archwizard Aruendel.
- 1 Kapten pasukan Aldric.

## Items Of Importance
 
- Artifact Bureau
- Amulet. Property; 1+ Wisdom Saves.
- Quarterstaff dengan ujung kepala naga. Property; 1d6 + 1 Fire Damage.

## What Worked 
-

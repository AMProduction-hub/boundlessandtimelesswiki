---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})** — [Oath of Vengeance]({{< relref "paladin-oath-of-vengeance" >}}) [Paladin]({{< relref "paladin" >}}) | [The Fiend]({{< relref "warlock-the-fiend" >}}) [Warlock]({{< relref "warlock" >}})  
- **[Minerva]({{< relref "minerva" >}})** — [Circle of Stars]({{< relref "druid-circle-of-stars-tce" >}}) [Druid]({{< relref "03playerloghandoutsmechanicscliclassesdruid" >}}) | [Life Domain]({{< relref "cleric-life-domain" >}}) [Cleric]({{< relref "cleric" >}})
- **[Froggo]({{< relref "froggo" >}})** — [Gloom Stalker]({{< relref "ranger-gloom-stalker-xge" >}}) [Ranger]({{< relref "03playerloghandoutsmechanicscliclassesranger" >}})  | [Rogue]({{< relref "03playerloghandoutsmechanicscliclassesrogue" >}})
- **[Verdian Suyanti]({{< relref "verdian-suyanti" >}})** — [College of Glamour]({{< relref "bard-college-of-glamour-xge" >}}) [Bard]({{< relref "bard" >}}) 
- **[Kairos]({{< relref "kairos" >}})** — [Soulknife]({{< relref "rogue-soulknife-tce" >}}) [Rogue]({{< relref "03playerloghandoutsmechanicscliclassesrogue" >}})
- [Asep]({{< relref "asep" >}}) — [Battle Smith]({{< relref "artificer-battle-smith-tce" >}}) [Artificer]({{< relref "artificer-tce" >}}) | [Bladesinging]({{< relref "wizard-bladesinging-tce" >}}) [Wizard]({{< relref "wizard" >}})

## Session Overview

> **“Fire... Water... Air... and Earth.”**  
>**“Law and Chaos. Order and Ruin.”**  
>**“Good... Evil... and everything that festers in between.”**
>
**“All bound by Time... or perhaps—Boundless... and Timeless.”**
>
**“Contractor... you already know the weight of the artifacts you carry.”**  
**“You’ve seen it... you’ve _felt_ it—the gods themselves trembling.”**
>
**“Everything that was once certain begins to defy its own nature...”**  
**“Pacts are broken. Honor... forgotten.”**
>
**“The Cold War among divinities has never ended.”**  
**“It only grew quieter... sharper... colder.”**  
**“And now... the one who once kept the balance has grown... sloppy.”**  
**“Using mortal hands to shape divine will.”**
>
**“So tell me, Contractor #777...”**  
**“Will you surrender all... to the Everywhere?”**  
**“Forge alliances with everything... or defy them all?”**
>
**“Because in the end... it seems everything now rests... in _your_ hands.”**
> Damian, The Contractor #666. 

Avatar Zariel tumbang... Damian berkata bahwa akan ada perang hebat antar divine... tetapi urusan kalian sekarang adalah untuk beristirahat, serahkan urusan esok untuk dirimu yang esok.

Kalian bermimpi dan didalam mimpi kalian didatangi oleh deity mu... doa-doa yang kau minta kepada mereka dan mereka datang kedalam mimpi mu... Atau mimpi tentang dunia mu yang sudah berbeda dari sekarang atau juga memimpikan dunia mu yang hancur dimasa itu dan di dalam mimpi itu kalian mendapatkan sebuah hadiah dan mereka yang mendatangi mimpimu meminta kalian melakukan sesuatu.

Di usai mimpi kalian, kalian melihat ada bayang bayang cahaya berwarna biru toska seperti artifact yang kalian ambil dan seketika kalian melihat dunia dari pandangan orang lain... pada waktu itu kalian melihat dari sudut pandang [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) yang tengah sekarat di ruang rawat di [Grand Library]({{< relref "grand-library" >}}) of Bureau of Time and Plane. Disana [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) kedatangan tamu yang kalian kenal yaitu [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).

> _"Dan kau… Kau kehilangan mata, lengan, hidupmu. Semua demi Biro. Balasannya? Sunyi. Bagi mereka, kau hanyalah alat sekali pakai."_
> - [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) kepada [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}).

Setelah kalian terlelap dalam tidur kapal kalian tiba di [Grand Library]({{< relref "grand-library" >}}), dan situasi disana yang waktu itu huru-hara sekarang menjadi lebih tegang dari sebelumnya. Party akhirnya bergegas melaporkan tugas mereka menuju [Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}}).

Ketika memasuki ruang, [Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}}) terlihat sehabis bersedih dan suaranya masih terdengar sehabis bersedih. Disana ia menekankan bahwa ada salah satu yang orang yang dikirim memberi tahu kepada [Mystra]({{< relref "faerunian-mystra-scag" >}}) sehingga [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) terserang langsung oleh [Mystra]({{< relref "faerunian-mystra-scag" >}}), [Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}}) menetapkan bahwa Party, [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}), Four Musician of Time, [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}), Ahab, dan Ishmael dalam pengawasan penuh karena sedang ada penyelidikan internal di Bureau. Selanjutnya party ditugaskan untuk menuju plane bernama 'The Frontier' dimana sihir tidak bisa berguna disana, dan party harus mengandalkan wit mereka masing-masing. Party akhirnya berangkat menuju the Frontier.

## Key Learnings

- Rhea dan [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) mendatangi mimpi [Sephire]({{< relref "sephire" >}}). Rhea memberikan Shield kepada [Sephire]({{< relref "sephire" >}})
- Tasha datang di mimpi [Froggo]({{< relref "froggo" >}}). Disana Tasha mengerjai [Froggo]({{< relref "froggo" >}}), tetapi pada akhir [Froggo]({{< relref "froggo" >}}) diberi sebuah panah.
- Seldarine, mendatangi mimpi [Verdian Suyanti]({{< relref "verdian-suyanti" >}}), disana ia diberi Cloak dan sebuah Boon.
- [Sheela Peryroyl]({{< relref "halfling-sheela-peryroyl-mtf" >}}) mendatangi mimpi [Minerva]({{< relref "minerva" >}}), disana [Sheela Peryroyl]({{< relref "halfling-sheela-peryroyl-mtf" >}}) memberikan sebuah amulet kepada [Minerva]({{< relref "minerva" >}}).
- [Kairos]({{< relref "kairos" >}}) mengingat kehancuran plane nya, ia mengingat kembali cara mengendalikan percikan api.
- [Asep]({{< relref "asep" >}}) sebuah divine machine, didalam istirahatnya dia mengingat kembali saudara-nya dan juga kegagalannya di-waktu lampau. Dari itu ia mengingat kembali sedikit kemampuannya.

## Who Did They Meet?

- Rhea dan [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) dari POV [Sephire]({{< relref "sephire" >}})
- Tasha dari POV [Froggo]({{< relref "froggo" >}})
- Seldarine dari POV [Verdian Suyanti]({{< relref "verdian-suyanti" >}})
- [Sheela Peryroyl]({{< relref "halfling-sheela-peryroyl-mtf" >}}) dari POV [Minerva]({{< relref "minerva" >}})
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) melalui POV [Shaperite - The Agent]({{< relref "shaperite-the-agent" >}}) dari efek Artifact Biru Toska.
- [Pustakawan - Second-in-Command]({{< relref "pustakawan-second-in-command" >}})
- Bartender [Grand Library]({{< relref "grand-library" >}}) of Bureau of Time and Plane.
- [Elira]({{< relref "the-daughter" >}}) yang bekerja di Requisition [Grand Library]({{< relref "grand-library" >}}).

## Items Of Importance

- Artifact Bureau berwarna Biru Toska.
- Shield of Rhea (+2 AC, +1 Saves Throws) milik [Sephire]({{< relref "sephire" >}}).
- Tasha's Bow of Laughter (+1, DC Caster vs WIS Saves Target kalau gagal terkena disadvantage untuk attack roll pada serangan pertama) milik [Froggo]({{< relref "froggo" >}}).
- Amulet of [Minerva]({{< relref "minerva" >}}) dari [Sheela Peryroyl]({{< relref "halfling-sheela-peryroyl-mtf" >}}) (2 Mass Healing Word + Blade Ward / Long Rest) milik [Minerva]({{< relref "minerva" >}}).
- Cloak of Arvandor ( +1 AC, +1 Saves Throws) dari Seldarine milik [Verdian Suyanti]({{< relref "verdian-suyanti" >}}).
- Boon of Seldarine (Reroll WIS Save Throws 1x / Long Rest) diberikan oleh Seldarine kepada [Verdian Suyanti]({{< relref "verdian-suyanti" >}}).
- Echo of Sol Prominence (1x +1d6 fire damage / long rest) oleh [Kairos]({{< relref "kairos" >}}).
- Core of Understanding (Free Cost & Action [Detect Magic]({{< relref "detect-magic" >}}) & [Identify]({{< relref "identify" >}}) | +1 DC Untuk Spell Pertama / Long Rest) untuk [Asep]({{< relref "asep" >}})

## What Worked

-

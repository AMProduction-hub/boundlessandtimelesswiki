---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})**. The Paladin 
 
- **[Kairos]({{< relref "kairos" >}}).** Soulknife Rogue. 
 
- **[Minerva]({{< relref "minerva" >}}).** Circle of Stars Druid / Life Cleric. 

- [Froggo]({{< relref "froggo" >}}). Gloomstalker Ranger

- [Verdian Suyanti]({{< relref "verdian-suyanti" >}}). The Bard

Away:
**[GomuGomuNo]({{< relref "gomugomuno" >}}).** The Monk. 
 
## Session Overview 
 
Party terbangun dari kematian di sekitar Benteng Caerthwyn dengan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) yang sedang menunggu mayat mereka dan memberikan informasi kalau [Elira]({{< relref "the-daughter" >}}) sedang berada di Nyx's Ring bersama ibu nya, akhirnya party berencana menuju Nyx's Ring setelah Long Rest. Seketika Party bangun, seharusnya mereka dapat melihat langit, mentari, dan awan tetapi pada kali ini langit gelap gulita tak ada bintang dan bulan yang menyinari, hanya cahaya yang menembus langit yang seperti bersumber dari Nyx's Ring. Party pun memulai perjalanan mereka menuju Nyx's Ring hingga melihat dari kejauhan terdengar suara kuda dan debu yang mulai terlihat tinggi dari jauh, ketika Party menepi mereka melihat di ujung depan pasukan kuda ini ada [Aldric]({{< relref "the-paladin" >}}) yang memimpin pasukan berkuda yang terlihat amat sangat banyak. Party melanjutkan perjalanan menuju Nyx's Ring dan menemukan kalau pasukan yang berkuda sedang menyusun camp di dekat Nyx's Ring dan disini Party split [Sephire]({{< relref "sephire" >}}), [Minerva]({{< relref "minerva" >}}), [Froggo]({{< relref "froggo" >}}), [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) mencoba memasuki camp [Aldric]({{< relref "the-paladin" >}}) sedangkan [Kairos]({{< relref "kairos" >}}) mencoba menuju Nyx's Ring.

## Key Learnings

- Party mengetahui bahwa betul [Aldric]({{< relref "the-paladin" >}}) yang memimpin pasukan berkuda untuk menghabisi para praktisi sihir di Nyx's Ring.
- [Kairos]({{< relref "kairos" >}}) menemui salah satu orang di camp Nyx's Ring yang meminta dia untuk mencari informasi bagaimana [Aldric]({{< relref "the-paladin" >}}) akan menyerang camp Nyx's Ring.
- Pedang yang ditemukan di Benteng Caerthwyn memiliki insignia keluarga Pelgrane. Sehingga pemegang dianggap pasukan kerajaan.
 
## Who Did They Meet?
 
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).
- [Ser Aldric, The Relentless]({{< relref "the-paladin" >}}).
- 1 Orang di Camp Nyx's Ring yang menemui [Kairos]({{< relref "kairos" >}}).

## Items Of Importance
 
- Pedang (Longsword) yang terdapat insignia keluarga Pelgrane yang dipegang oleh [Sephire]({{< relref "sephire" >}}).

## What Worked 
- Apakah party akan memihak kepada [Ser Aldric, The Relentless]({{< relref "the-paladin" >}}) atau para praktisi sihir di Nyx's Ring ?

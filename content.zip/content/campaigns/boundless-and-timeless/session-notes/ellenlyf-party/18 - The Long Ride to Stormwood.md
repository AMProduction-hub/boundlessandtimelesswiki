---
tags:
  - timeline
  - SessionJournals
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})** — [Oath of Vengeance]({{< relref "paladin-oath-of-vengeance" >}}) [Paladin]({{< relref "paladin" >}}) | [The Fiend]({{< relref "warlock-the-fiend" >}}) [Warlock]({{< relref "warlock" >}})  
- **[Minerva]({{< relref "minerva" >}})** — [Circle of Stars]({{< relref "druid-circle-of-stars-tce" >}}) [Druid]({{< relref "03playerloghandoutsmechanicscliclassesdruid" >}}) | [Life Domain]({{< relref "cleric-life-domain" >}}) [Cleric]({{< relref "cleric" >}})
- **[Froggo]({{< relref "froggo" >}})** — [Gloom Stalker]({{< relref "ranger-gloom-stalker-xge" >}}) [Ranger]({{< relref "03playerloghandoutsmechanicscliclassesranger" >}})  | [Rogue]({{< relref "03playerloghandoutsmechanicscliclassesrogue" >}})
- **[Verdian Suyanti]({{< relref "verdian-suyanti" >}})** — [College of Glamour]({{< relref "bard-college-of-glamour-xge" >}}) [Bard]({{< relref "bard" >}}) 
- **[Kairos]({{< relref "kairos" >}})** — [Soulknife]({{< relref "rogue-soulknife-tce" >}}) [Rogue]({{< relref "03playerloghandoutsmechanicscliclassesrogue" >}}) *(Absent)*
- **[Asep]({{< relref "asep" >}})** — [Battle Smith]({{< relref "artificer-battle-smith-tce" >}}) [Artificer]({{< relref "artificer-tce" >}}) | [Bladesinging]({{< relref "wizard-bladesinging-tce" >}}) [Wizard]({{< relref "wizard" >}})

## Session Overview

The party arrived in the **Frontier Plane**, traveling through the dead woods of **Stormwood** — a forest scarred by lightning strikes, perpetual fog, and silence.  
They were guided to **Red Jack’s hideout**, a temporary base hidden deep within the forest.

The party was given time to rest extensively (16 hours total), burning through Hit Dice and preparing for a high-risk operation scheduled for the following midnight.

Red Jack briefed the party on the plan:
- An **oil tank carriage** had already been smuggled into a cave in **Le Grant Kanyun**
- The party’s task was to stop the Baron’s train using the carriage and secure its contents

The tone of the session emphasized inevitability — no speeches, no rallying cries, just preparation and quiet resolve.

## Key Learnings

- This plane operates on **violence as procedure**, not chaos
- Red Jack is not reckless — he is resigned
- Rest does not erase dread; it only delays it

## Who Did They Meet?

- **Red Jack** — Outlaw leader, visibly tired, quietly determined

## Items Of Importance

- **Oil Tank Carriage** — Volatile, central to stopping the train
- Maps of **Le Grant Kanyun** and surrounding rail lines

## What Worked

- Extended downtime increased tension instead of reducing it
- The environment reinforced the theme of “no clean exits”
- Players leaned into preparation and role separation

---
tags: [timeline, SessionJournals]
---
## Characters 
 
- **[Sephire]({{< relref "sephire" >}})** — Paladin / Warlock  
- **[Minerva]({{< relref "minerva" >}})** — Circle of Stars Druid / Life Cleric  
- **[Froggo]({{< relref "froggo" >}})** — Gloomstalker Ranger  
- **[Verdian Suyanti]({{< relref "verdian-suyanti" >}})** — Bard  
- **[Kairos]({{< relref "kairos" >}})** — Soulknife Rogue  

## Session Overview

***Pukul 02.00.*** 
[Minerva]({{< relref "minerva" >}}), [Sephire]({{< relref "sephire" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) mencoba mencari cara untuk dapat masuk kedalam Bastion of [Stalwart]({{< relref "stalwart" >}}) yang sedang di lockdown, [Minerva]({{< relref "minerva" >}}) menemukan sebuah lubang dan dia berubah menjadi [Giant Badger]({{< relref "giant-badger" >}}) untuk menggali jalan supaya [Sephire]({{< relref "sephire" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) bisa masuk. Ketika party sudah masuk mereka melihat diatas tembok tentara [Stalwart]({{< relref "stalwart" >}}) dan pasukan [Fremen]({{< relref "fremen" >}}) sedang adu negosiasi hingga [Stalwart]({{< relref "stalwart" >}}) menampakkan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dari atas tembok ke hadapan para [Fremen]({{< relref "fremen" >}}) dan mengancam apabila [Fremen]({{< relref "fremen" >}}) menyerang maka [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) akan terbang ke arah pasukan [Fremen]({{< relref "fremen" >}}), setelah itu para negosiator mulai tenang dan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dibawa ke Inn Bastion of [Stalwart]({{< relref "stalwart" >}}). Party akhirnya berencana menyelamatkan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}).

[Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) sedang beristirahat disekitar lapangan Tunnel of Grim sambil memikirkan rencana selanjutnya dan mencoba mendeduksi apa yang terjadi. Kemudian datanglah [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) yang mengajak [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) membahas apa saja yang terjadi dan membuka pikiran bersama. Setelah party berdiskusi dengan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) dapat ditunjukkan bahwa barrier yang ada di reruntuhan adalah sihir yang bersumber dari [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}}) dan di Shattar-Kai yang paling dekat adalah House of Silence yang merupakan temple dari [Kelemvor]({{< relref "faerunian-kelemvor-scag" >}}). Kemudian [Froggo]({{< relref "froggo" >}}), [Kairos]({{< relref "kairos" >}}), dan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) bergegas mendatangi reruntuhan yang masih tertutup yang sekarang sihir-sihir divine sudah di hilangkan dan mulai bergegas menggali reruntuhannya. Dibalik reruntuhan terdapat sebuah podium dan sepucuk surat dari [Father Malen]({{< relref "father-malen" >}}). [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) menduga akan adanya kedatangan eldritch being jika batu itu benar-benar digunakan, dia mengingatkan party untuk mengajak [Fremen]({{< relref "fremen" >}}) & [Stalwart]({{< relref "stalwart" >}}) bersatu apabila iya terjadi. [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) mengatakan kalau dia merasakan ada hawa-hawa dari Nine Hells of Baator yang akan datang.

***Pukul 02.30.***
Ledakan besar terdengar dari arah Bastion of Stalwart. [Minerva]({{< relref "minerva" >}}), [Sephire]({{< relref "sephire" >}}), [Verdian Suyanti]({{< relref "verdian-suyanti" >}}), [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) & 3 tawanan lain yang berhasil keluar dari Bastion of [Stalwart]({{< relref "stalwart" >}}) mereka tersempar dari shockwave ledakan yang meledakkan tembok Bastion of [Stalwart]({{< relref "stalwart" >}}).

[Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) yang mendengar ledakan itu dari dalam Tunnel of Grim berusaha keluar menuju ke area lapangan Tunnel of Grim. Ternyata para tentara [Stalwart]({{< relref "stalwart" >}}) sudah siap menyerang dan para wizard dari [Stalwart]({{< relref "stalwart" >}}) juga sudah membuatkan [Teleportation Circle]({{< relref "teleportation-circle" >}}) yang menuju [Fremen]({{< relref "fremen" >}}) Camp, disanalah [Stalwart]({{< relref "stalwart" >}}) akan melaksanakan serangannya. [General Valtan]({{< relref "general-valtan" >}}) menyampaikan sebuah pidato kepada pasukannya dan pasukan mulai menuju [Teleportation Circle]({{< relref "teleportation-circle" >}}) yang dibuat oleh [Wizard]({{< relref "wizard" >}}) [Stalwart]({{< relref "stalwart" >}}). [Froggo]({{< relref "froggo" >}}) & [Kairos]({{< relref "kairos" >}}) mencoba mencari petinggi [Stalwart]({{< relref "stalwart" >}}) di Tunnel of Grim tetapi hanya menemukan [Eric Valtan]({{< relref "eric-valtan" >}}) dimana dia bilang dia ingin pergi ke Bastion of [Stalwart]({{< relref "stalwart" >}}) untuk menyelamatkan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}), party pun akan menuju Bastion of [Stalwart]({{< relref "stalwart" >}}) dengan bantuan [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) dan seketika party bertemu dengan seluruh anggota.

[Froggo]({{< relref "froggo" >}}), [Kairos]({{< relref "kairos" >}}), [Minerva]({{< relref "minerva" >}}), [Sephire]({{< relref "sephire" >}}) & [Verdian Suyanti]({{< relref "verdian-suyanti" >}}) sudah berkumpul kembali di daerah stable di Bastion of [Stalwart]({{< relref "stalwart" >}}), disana [Eric Valtan]({{< relref "eric-valtan" >}}) bergegas merangkul [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dan mencoba membangunkannya. Party mencoba berdiskusi langkah apa yang akan diambil selanjutnya, seketika House of Silence memancarkan cahaya merah yang menembus langit dan datanglah para imp dan juga cambion-cambion. [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) pun menutup sesi dengan perkataan *"Invasi [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) sudah dimulai"*. 

## Key Learnings

- [Father Malen]({{< relref "father-malen" >}}) yang memegang artefak batu toska.
- [Stalwart]({{< relref "stalwart" >}}) dan [Fremen]({{< relref "fremen" >}}) sedang memulai perang ketika pasukan [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}}) masuk.
- [Eric Valtan]({{< relref "eric-valtan" >}}) dan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) berpelukan ketika bertemu.
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}) mengingatkan kalau [Fremen]({{< relref "fremen" >}}) dan [Stalwart]({{< relref "stalwart" >}}) bisa membantu party untuk menghadapi pasukan [Zariel]({{< relref "03playerloghandoutsmechanicsclibestiarynpczariel-mpmm" >}})  

## Who Did They Meet?

- [General Valtan]({{< relref "general-valtan" >}})  
- [Eric Valtan]({{< relref "eric-valtan" >}})
- [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}})
- [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}})
- 3 Tawanan [Stalwart]({{< relref "stalwart" >}}) yang ada di Inn

## Items Of Importance

- Cermin dari [Damian - The Squeeky Devils]({{< relref "damian-the-squeeky-devils" >}}).

## What Worked

- Menyelamatkan [Sofia Fyrwurd]({{< relref "sofia-fyrwurd" >}}) dari kekacauan di Bastion of [Stalwart]({{< relref "stalwart" >}}).

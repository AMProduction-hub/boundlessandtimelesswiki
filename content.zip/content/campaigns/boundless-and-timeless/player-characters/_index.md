---
title: "Player Characters"
bookCollapseSection: true
---

# Player Characters

Meet the heroes answering The Bureau's call.

## Ellenlyf Party ( Active)

### **[Kairos]({{< relref "kairos" >}})**
**Class**: 8 Rogue - Soul Knife  
**Race**: Elf - Astral  

---

### **[Froggo]({{< relref "froggo" >}})**
**Class**: 6 Ranger - Gloom Stalker | 2 Rogue  
**Race**: Grung (Custom Lineage)  

---

### **[Minerva]({{< relref "minerva" >}})**
**Class**: 7 Druid - Circle of Stars | 1 Cleric - Life Domain  
**Race**: Satyr (Custom Lineage)  

---

### **[Sephire]({{< relref "sephire" >}})**
**Class**: 6 Paladin - Oath of Vengeance | 2 Warlock - The Fiend  
**Race**: Half-Orc  

---

### **[Asep]({{< relref "asep">}})**
**Class**: 5 Wizard - Bladesinging | 3 Artificier - Battlesmith  
**Race**: Orc (MPMM)  

---

### **[Verdian Suyanti]({{< relref "verdian-suyanti" >}})**
**Class**: 8 Bard - College of Glamour  
**Race**: Half-Elf  

---

---

## C'est La Vie Party (✅ Completed)

### **[Gwyn]({{< relref "gwyn" >}})**
**Class**: 6 Paladin - Oath of The Ancient  
**Race**: Human (Variant)  

---

### **[Ashenka Roïs]({{< relref "ashenka-rois" >}})**
**Class**: 6 Monk - Way of The Long Death  
**Race**: Elf Shaddar-Kai

---

### **[Meows Whiskerpop (Whisky)]({{< relref "whisky" >}})**
**Class**: 6 Warlock - The Great Old One  
**Race**: Tabaxi

---

### **[Jeno]({{< relref "jeno" >}})**
**Class**: 6 Wizard - Evocation  
**Race**: Tabaxi  

---

### **[Klir]({{< relref "klir" >}})**
**Class**: Rogue - Assassin   
**Race**: Tortle  

---

## Former Members

### **[Alizar Valts]({{< relref "alizar-valts" >}})**
**Class**: 5 Fighter (Battle Master)  
**Race**: High Elf  

Elven two-weapon fighter seeking truth about his destroyed village while honoring his parents' lessons.

*Former member of C'est La Vie Party*

---

{{< hint info >}}
**For Players**: Keep your character sheets updated! Let me know if you want to add backstory details or update your character information.
{{< /hint >}}

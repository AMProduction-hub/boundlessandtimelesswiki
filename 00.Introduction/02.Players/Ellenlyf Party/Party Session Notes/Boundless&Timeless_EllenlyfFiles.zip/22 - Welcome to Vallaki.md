---
tags:
  - timeline
  - SessionJournals
---
<div
  class='ob-timelines'
  data-date='144-43-49-00'
  data-title='dd-mm-yyy desc'
  data-class='orange'
  data-img = '\z_Assets\ImagePlaceholder.png'
  data-type='range'
  data-end="2000-10-20-00">
  The not so Dread huh ?
</div>

## Characters 
 
- **[[Sephire]]** — Oath of Vengeance Paladin | The Fiend Warlock  
- **[[Minerva]]** — Circle of Stars Druid | Life Domain Cleric
- **[[Froggo]]** — Gloom Stalker Ranger  | Rogue
- **[[Verdian Suyanti]]** — College of Glamour Bard
- **[[Kairos]]** — Soulknife Rogue
- **[[Asep]]** — Battle Smith Artificer | Bladesinging Wizard
 
## Session Overview 
 
Deep fog covered Lake Zarovich. After nearly being beaten by enemies at the shores, the party finally made it back to the Pequod.

**HAWA**, who had just woken up after a magically-induced rest, began praying on the Pequod's deck while watching the shore where the party had battled. **Sephire** tried to overhear what HAWA was doing and heard her mentioning _"Lady Silver..."_ He told the rest of the party, and they recognized this as a prayer to **Selûne**.

**Sephire** approached HAWA.

_"Have your prayers been answered, Paladin?"_ she asked him.

**Sephire** has been dealing with conflicting loyalties—Rhea (his goddess) and Zariel (his patron) have both been pulling him in different directions regarding the Netherese Stones situation.

_"I have not been praying in a while..."_ Sephire admitted.

**HAWA** opened her eyes but continued looking at the shores. _"We need every help we can get. You already know the gods from Mount Celestia have decided to join the Blood War to end it once and for all."_

**HAWA** then explained what has happened in Barovia based on what she's learned during her 6 months stationed here. She mentioned that **Strahd Von Zarovich** disappeared 100 years ago. Since then, mortals and vampires have coexisted—mortals pay a monthly "Blood Tax," and if someone breaks the law, mysterious enforcers are sent to "take care" of them.

This behavior is very odd for vampires, since it means they're organizing rather than operating in the typical vampire hierarchy. This could prove disastrous if the vampires have secret agendas the mortals don't know about. **HAWA** plans to understand what the Netherese Stones she found in Castle Ravenloft's dungeons are being used for, and what the vampires' true agenda is.

**HAWA** asked the party to follow her to her safehouse in Vallaki at an inn called **The Silent Inn**, where she's been operating for 6 months. The party knows their official Bureau of Time and Plane mission is to take the stones and leave without interfering, but they decided to investigate the vampire conspiracy anyway. Some also want souvenirs from this plane.
## Key Learnings

- Based on **HAWA's** prayer, the party deduced that she follows **Selûne** (goddess of the moon).
- **HAWA** has been in this plane for 6 months but has never met **ADAM**, another Bureau agent supposedly stationed here. She was told ADAM is a local, but he has never appeared.
- Mortals and vampires coexist. Every month, all mortals of coming-of-age and older must pay a **Blood Tax**.
- **Strahd Von Zarovich** disappeared at least 100 years ago. Based on **Froggo's** knowledge from his time as Tasha's pet, he deduced this happened around the same time as the **Throne of Bhaal** event (when Bhaalspawn named Balthazar and Bhaal's Priest Amelyssan's plans were stopped by Gorion's Ward).
- **HAWA** mentioned that vampires don't usually organize—they operate by individual hierarchy. This organized behavior is very odd and makes them much harder to handle. She said _"1,000 unorganized vampires are easier to handle than 100 vampires that are organized and working toward the same ideals."_ If someone in Barovia breaks laws, mysterious groups are sent to "take care" of them.
- **Castle Ravenloft's** dungeons held the Netherese Stones (deep purple in color) the Bureau is looking for. **HAWA** recovered them before traveling to Lake Zarovich to meet the party.
- **HAWA** knows Contractor #777 (the party) is supposed to take the stones and leave without interfering. However, she asked if deep in their hearts they wanted to know more about what's happening with the vampires. The party agreed to investigate.
- **HAWA** has a safehouse at an inn in Vallaki called **The Silent Inn**, where everyone must be quiet at all times and use sign language.
- In 4 days, there will be a festival in Vallaki celebrating the anniversary of the Vallaki bloodline. The current monarch is **Bartholomeus Vallaki XIII**.
- Vallaki is split into 5 sections:
    - **Lower City** (lower class)
    - **Central City** (market area, where The Silent Inn is located)
    - **Uptown** (middle class housing)
    - **Grand Boulevard** (noble/upper class)
    - **Vallaki Castle Area**
- Time flows strangely here—during the 4-hour journey from Lake Zarovich to Vallaki, the moon crossed the sky twice.
 
## Who Did They Meet?
 
- **[[HAWA]]** — Bureau agent stationed in Barovia for 6 months, follower of Selûne
- **2 Guards at Vallaki's Gate** — One was extremely pale (possibly a vampire or thrall)
- **Innkeeper of The Silent Inn** — Runs an inn where patrons must use sign language
 
## Items Of Importance
 
- **The Netherese Stone** (deep purple color) — Currently carried by HAWA. She found it beneath Castle Ravenloft.

## What Worked 
 
- The quiet moment between Sephire and HAWA created good character development
- HAWA's exposition about Barovia was clear and set up future investigation
- The party's choice to investigate despite Bureau orders showed character growth
- Time anomaly (moon crossing twice) established Barovia's otherworldly nature
